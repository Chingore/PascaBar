import { AppDataBackup } from '../types';
import { storageService } from './storage';

export interface CloudSyncState {
  isOnline: boolean;
  isSyncing: boolean;
  lastSyncTime: string | null;
  lastSyncSuccess: boolean;
  errorMessage: string | null;
}

type SyncListener = (state: CloudSyncState) => void;

class CloudSyncManager {
  private state: CloudSyncState = {
    isOnline: typeof navigator !== 'undefined' ? navigator.onLine : true,
    isSyncing: false,
    lastSyncTime: null,
    lastSyncSuccess: true,
    errorMessage: null,
  };

  private listeners: Set<SyncListener> = new Set();
  private autoSyncInterval: any = null;

  constructor() {
    if (typeof window !== 'undefined') {
      window.addEventListener('online', () => this.handleNetworkChange(true));
      window.addEventListener('offline', () => this.handleNetworkChange(false));
      
      const storedLastSync = localStorage.getItem('pascbar_last_sync_time');
      if (storedLastSync) {
        this.state.lastSyncTime = storedLastSync;
      }
    }
  }

  public subscribe(listener: SyncListener) {
    this.listeners.add(listener);
    listener(this.state);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach((fn) => fn({ ...this.state }));
  }

  private handleNetworkChange(online: boolean) {
    this.state.isOnline = online;
    if (online) {
      this.state.errorMessage = null;
      // Auto-trigger sync when returning online
      this.syncNow();
    } else {
      this.state.errorMessage = 'Sem conexão com a internet (Modo Offline)';
    }
    this.notify();
  }

  public startAutoSync(intervalMs = 25000) {
    if (this.autoSyncInterval) clearInterval(this.autoSyncInterval);
    this.autoSyncInterval = setInterval(() => {
      const settings = storageService.getSettings();
      if (settings.autoCloudSync && this.state.isOnline) {
        this.syncNow();
      }
    }, intervalMs);
  }

  public stopAutoSync() {
    if (this.autoSyncInterval) {
      clearInterval(this.autoSyncInterval);
      this.autoSyncInterval = null;
    }
  }

  // Push local state to cloud backup endpoint
  public async syncNow(): Promise<{ success: boolean; message?: string }> {
    if (!this.state.isOnline) {
      return { success: false, message: 'Dispositivo sem internet. Dados seguros localmente.' };
    }

    const settings = storageService.getSettings();
    const backupCode = settings.backupCode.trim().toUpperCase();
    const backupData = storageService.getFullBackup();

    this.state.isSyncing = true;
    this.notify();

    try {
      const response = await fetch(`/api/cloud/sync/${encodeURIComponent(backupCode)}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          backupCode,
          barName: settings.barName,
          data: backupData,
          clientTimestamp: new Date().toISOString(),
        }),
      });

      if (!response.ok) {
        throw new Error(`Falha no servidor: status ${response.status}`);
      }

      const result = await response.json();
      const nowStr = new Date().toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      this.state.isSyncing = false;
      this.state.lastSyncTime = nowStr;
      this.state.lastSyncSuccess = true;
      this.state.errorMessage = null;
      if (typeof window !== 'undefined') {
        localStorage.setItem('pascbar_last_sync_time', nowStr);
      }
      this.notify();
      return { success: true, message: 'Sincronizado na nuvem com sucesso!' };
    } catch (err: any) {
      this.state.isSyncing = false;
      this.state.lastSyncSuccess = false;
      this.state.errorMessage = 'Sincronização em segundo plano pausada.';
      this.notify();
      return { success: false, message: err.message || 'Erro na sincronização' };
    }
  }

  // Recover bar data from cloud when phone is lost or changed
  public async restoreFromCloud(backupCode: string): Promise<{ success: boolean; message: string; backup?: AppDataBackup }> {
    const cleanCode = backupCode.trim().toUpperCase();
    if (!cleanCode) {
      return { success: false, message: 'Insira um código de recuperação válido.' };
    }

    try {
      const response = await fetch(`/api/cloud/restore/${encodeURIComponent(cleanCode)}`);
      if (response.status === 404) {
        return {
          success: false,
          message: `Código "${cleanCode}" não encontrado na nuvem. Verifique o código.`,
        };
      }
      if (!response.ok) {
        return { success: false, message: 'Erro ao comunicar com o servidor de backup.' };
      }

      const result = await response.json();
      if (!result.data) {
        return { success: false, message: 'Backup da nuvem corrompido ou vazio.' };
      }

      const restored = storageService.restoreFromBackup(result.data);
      if (restored) {
        // Update local settings backup code to match restored
        const s = storageService.getSettings();
        s.backupCode = cleanCode;
        storageService.saveSettings(s);

        const nowStr = new Date().toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' });
        this.state.lastSyncTime = nowStr;
        this.notify();

        return {
          success: true,
          message: `Dados recuperados com sucesso! Bar: ${result.barName || cleanCode}.`,
          backup: result.data,
        };
      } else {
        return { success: false, message: 'Falha ao processar os dados restaurados.' };
      }
    } catch (err: any) {
      return {
        success: false,
        message: err.message || 'Falha na conexão com a nuvem para recuperação.',
      };
    }
  }
}

export const cloudSyncManager = new CloudSyncManager();
