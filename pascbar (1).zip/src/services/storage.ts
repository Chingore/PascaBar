import { Product, Sale, CashClosure, Expense, BarSettings, LicenseState, AppDataBackup } from '../types';

const STORAGE_KEYS = {
  PRODUCTS: 'pascbar_products_v1',
  SALES: 'pascbar_sales_v1',
  CLOSURES: 'pascbar_closures_v1',
  EXPENSES: 'pascbar_expenses_v1',
  SETTINGS: 'pascbar_settings_v1',
  LICENSE: 'pascbar_license_v1',
  LAST_CLOUD_SYNC: 'pascbar_last_cloud_sync',
};

// Initial empty catalog so the bar owner adds their own drinks from scratch
export const DEFAULT_PRODUCTS: Product[] = [];

function generateBackupCode(): string {
  const randNum = Math.floor(1000 + Math.random() * 9000);
  return `PASC-${randNum}`;
}

export const DEFAULT_SETTINGS: BarSettings = {
  barName: 'PascBar',
  currency: 'MT',
  backupCode: generateBackupCode(),
  soundEnabled: true,
  fastSaleMode: false,
  autoCloudSync: true,
};

export const DEFAULT_LICENSE: LicenseState = {
  isActivated: false,
  installedAt: new Date().toISOString(),
  trialDays: 7,
};

// Local storage helper with try/catch for private browsing / quota
export const storageService = {
  getProducts(): Product[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
      if (!data) {
        this.saveProducts(DEFAULT_PRODUCTS);
        return DEFAULT_PRODUCTS;
      }
      const parsed = JSON.parse(data);
      // If storage has the old demo seed products, auto-clear them so user starts completely clean
      if (Array.isArray(parsed) && parsed.some((p: any) => p.id === 'prod-1' || p.id === 'prod-2' || p.name === 'Cerveja 2M')) {
        this.saveProducts([]);
        return [];
      }
      return parsed;
    } catch (e) {
      console.error('Failed reading products from storage', e);
      return DEFAULT_PRODUCTS;
    }
  },

  saveProducts(products: Product[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
    } catch (e) {
      console.error('Failed saving products to storage', e);
    }
  },

  getSales(): Sale[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SALES);
      if (!data) return [];
      const parsed = JSON.parse(data);
      // Clear demo sales associated with demo products
      if (Array.isArray(parsed) && parsed.some((s: any) => s.items?.some((i: any) => i.productId === 'prod-1'))) {
        this.saveSales([]);
        return [];
      }
      return parsed;
    } catch {
      return [];
    }
  },

  saveSales(sales: Sale[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.SALES, JSON.stringify(sales));
    } catch (e) {
      console.error('Failed saving sales', e);
    }
  },

  clearAllRecords(): void {
    this.saveProducts([]);
    this.saveSales([]);
    this.saveClosures([]);
    this.saveExpenses([]);
  },

  getClosures(): CashClosure[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CLOSURES);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveClosures(closures: CashClosure[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.CLOSURES, JSON.stringify(closures));
    } catch (e) {
      console.error('Failed saving closures', e);
    }
  },

  getExpenses(): Expense[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.EXPENSES);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveExpenses(expenses: Expense[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify(expenses));
    } catch (e) {
      console.error('Failed saving expenses', e);
    }
  },

  getSettings(): BarSettings {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      if (!data) {
        this.saveSettings(DEFAULT_SETTINGS);
        return DEFAULT_SETTINGS;
      }
      return { ...DEFAULT_SETTINGS, ...JSON.parse(data) };
    } catch {
      return DEFAULT_SETTINGS;
    }
  },

  saveSettings(settings: BarSettings): void {
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch (e) {
      console.error('Failed saving settings', e);
    }
  },

  getLicense(): LicenseState {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.LICENSE);
      if (!data) {
        this.saveLicense(DEFAULT_LICENSE);
        return DEFAULT_LICENSE;
      }
      return JSON.parse(data);
    } catch {
      return DEFAULT_LICENSE;
    }
  },

  saveLicense(license: LicenseState): void {
    try {
      localStorage.setItem(STORAGE_KEYS.LICENSE, JSON.stringify(license));
    } catch (e) {
      console.error('Failed saving license', e);
    }
  },

  // Export full snapshot for cloud backup or file download
  getFullBackup(): AppDataBackup {
    const settings = this.getSettings();
    return {
      version: 1,
      exportedAt: new Date().toISOString(),
      backupCode: settings.backupCode,
      settings,
      license: this.getLicense(),
      products: this.getProducts(),
      sales: this.getSales(),
      closures: this.getClosures(),
      expenses: this.getExpenses(),
    };
  },

  // Restore snapshot (e.g. from cloud or file)
  restoreFromBackup(backup: AppDataBackup): boolean {
    try {
      if (!backup || !backup.products) return false;
      if (backup.settings) this.saveSettings(backup.settings);
      if (backup.license) this.saveLicense(backup.license);
      if (backup.products) this.saveProducts(backup.products);
      if (backup.sales) this.saveSales(backup.sales);
      if (backup.closures) this.saveClosures(backup.closures);
      if (backup.expenses) this.saveExpenses(backup.expenses);
      return true;
    } catch (err) {
      console.error('Error restoring backup', err);
      return false;
    }
  },
};
