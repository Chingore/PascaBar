import React, { useState, useMemo } from 'react';
import { Sale, CashClosure, PaymentMethod } from '../types';
import { soundFX } from '../services/audio';
import { PAYMENT_CONFIGS, normalizePaymentMethod, getPaymentMethodName } from '../utils/payment';
import { 
  DollarSign, 
  TrendingUp, 
  Lock, 
  RotateCcw, 
  FileText, 
  CheckCircle2, 
  Calendar, 
  Clock, 
  Banknote, 
  Smartphone, 
  CreditCard, 
  AlertCircle,
  Share2,
  Printer,
  ChevronDown,
  ChevronUp
} from 'lucide-react';

interface DailyReportViewProps {
  salesToday: Sale[];
  closures: CashClosure[];
  currency: string;
  barName: string;
  selectedDate: string; // YYYY-MM-DD
  onChangeDate: (date: string) => void;
  onReverseSale: (saleId: string) => void;
  onExecuteCashClosure: (closureData: Omit<CashClosure, 'id' | 'closedAt'>) => void;
}

export const DailyReportView: React.FC<DailyReportViewProps> = ({
  salesToday,
  closures,
  currency,
  barName,
  selectedDate,
  onChangeDate,
  onReverseSale,
  onExecuteCashClosure,
}) => {
  const [isClosureModalOpen, setIsClosureModalOpen] = useState(false);
  const [physicalCashCounted, setPhysicalCashCounted] = useState<string>('');
  const [closureNotes, setClosureNotes] = useState('');
  const [closedBy, setClosedBy] = useState('');
  const [showHistory, setShowHistory] = useState(false);
  const [lastClosureSummary, setLastClosureSummary] = useState<CashClosure | null>(null);

  // Filter valid sales
  const validSales = useMemo(() => salesToday.filter((s) => !s.isReversed), [salesToday]);
  const reversedSales = useMemo(() => salesToday.filter((s) => s.isReversed), [salesToday]);

  // Daily Totals
  const totalRevenue = useMemo(() => validSales.reduce((acc, s) => acc + s.totalAmount, 0), [validSales]);
  const totalCost = useMemo(() => validSales.reduce((acc, s) => acc + s.totalCost, 0), [validSales]);
  const totalProfit = totalRevenue - totalCost;
  const profitMargin = totalRevenue > 0 ? Math.round((totalProfit / totalRevenue) * 100) : 0;

  const totalDrinksSold = useMemo(
    () => validSales.reduce((acc, s) => acc + s.items.reduce((sum, i) => sum + i.quantity, 0), 0),
    [validSales]
  );

  // Payment method breakdown
  const paymentBreakdown = useMemo(() => {
    const acc = { 
      fisico: 0, 
      emola: 0, 
      mpesa: 0, 
      mkash: 0, 
      cartao: 0, 
      fiado: 0, 
      outro: 0,
      dinheiro: 0,
      mpesa_emola: 0
    };
    validSales.forEach((s) => {
      const norm = normalizePaymentMethod(s.paymentMethod);
      acc[norm] = (acc[norm] || 0) + s.totalAmount;
    });
    // Ensure legacy aliases are populated for backward compatibility
    acc.dinheiro = acc.fisico;
    acc.mpesa_emola = acc.mpesa + acc.emola;
    return acc;
  }, [validSales]);

  // Top products sold today
  const topProductsToday = useMemo(() => {
    const map: Record<string, { name: string; quantity: number; revenue: number; profit: number }> = {};
    validSales.forEach((s) => {
      s.items.forEach((item) => {
        if (!map[item.productId]) {
          map[item.productId] = { name: item.productName, quantity: 0, revenue: 0, profit: 0 };
        }
        map[item.productId].quantity += item.quantity;
        map[item.productId].revenue += item.subtotal;
        map[item.productId].profit += item.profit;
      });
    });
    return Object.values(map).sort((a, b) => b.quantity - a.quantity).slice(0, 5);
  }, [validSales]);

  // Check if today already has a closure
  const todayClosure = useMemo(() => closures.find((c) => c.dateStr === selectedDate), [closures, selectedDate]);

  // Handle cash closure submission
  const handleConfirmClosure = () => {
    const countedCash = physicalCashCounted !== '' ? parseFloat(physicalCashCounted) : undefined;
    const expectedCash = paymentBreakdown.fisico ?? paymentBreakdown.dinheiro ?? 0;
    const diff = countedCash !== undefined ? countedCash - expectedCash : undefined;

    const newClosure: Omit<CashClosure, 'id' | 'closedAt'> = {
      dateStr: selectedDate,
      totalRevenue,
      totalCost,
      totalProfit,
      totalSalesCount: validSales.length,
      totalDrinksSold,
      paymentBreakdown,
      physicalCashCounted: countedCash,
      cashDifference: diff,
      notes: closureNotes.trim() || undefined,
      closedBy: closedBy.trim() || 'Vendedor',
    };

    onExecuteCashClosure(newClosure);
    setIsClosureModalOpen(false);
    setLastClosureSummary({
      ...newClosure,
      id: `closure-${Date.now()}`,
      closedAt: new Date().toISOString(),
    });
    soundFX.playSaleChime();
  };

  // WhatsApp Share receipt text generator
  const generateWhatsAppShareText = (closure: CashClosure) => {
    const cashVal = (closure.paymentBreakdown.fisico ?? closure.paymentBreakdown.dinheiro ?? 0).toLocaleString('pt-PT');
    const emolaVal = (closure.paymentBreakdown.emola ?? 0).toLocaleString('pt-PT');
    const mpesaVal = (closure.paymentBreakdown.mpesa ?? closure.paymentBreakdown.mpesa_emola ?? 0).toLocaleString('pt-PT');
    const mkashVal = (closure.paymentBreakdown.mkash ?? 0).toLocaleString('pt-PT');
    const cartaoVal = (closure.paymentBreakdown.cartao ?? 0).toLocaleString('pt-PT');
    const fiadoVal = (closure.paymentBreakdown.fiado ?? 0).toLocaleString('pt-PT');

    const text = `🍻 *FECHO DIÁRIO - ${barName.toUpperCase()}*\n📅 Data: ${closure.dateStr}\n------------------------------\n💰 *Receita Total:* ${closure.totalRevenue.toLocaleString('pt-PT')} ${currency}\n📉 *Custo Mercadoria:* ${closure.totalCost.toLocaleString('pt-PT')} ${currency}\n💎 *LUCRO LÍQUIDO:* ${closure.totalProfit.toLocaleString('pt-PT')} ${currency}\n🍹 *Bebidas Servidas:* ${closure.totalDrinksSold} un.\n\n*Formas de Pagamento:*\n💵 Físico (Dinheiro): ${cashVal} ${currency}\n🟠 e-Mola (Movitel): ${emolaVal} ${currency}\n🔴 M-Pesa (Vodacom): ${mpesaVal} ${currency}\n🟡 M-Kash (Tmcel): ${mkashVal} ${currency}\n💳 Cartão/POS: ${cartaoVal} ${currency}\n⏳ Fiados: ${fiadoVal} ${currency}\n${closure.physicalCashCounted !== undefined ? `\n🔎 Dinheiro Contado em Gaveta: ${closure.physicalCashCounted} ${currency} (Diferença: ${closure.cashDifference} ${currency})` : ''}\n${closure.notes ? `\n📝 Obs: ${closure.notes}` : ''}\n👤 Fechado por: ${closure.closedBy || 'Vendedor'}\n------------------------------\n_Gerado por PascBar_`;
    return encodeURIComponent(text);
  };

  return (
    <div className="space-y-4">
      {/* Date Bar & Closure Status */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4 shadow-md">
        <div className="flex items-center gap-3">
          <Calendar className="w-5 h-5 text-amber-400" />
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
              Data do Relatório
            </span>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => onChangeDate(e.target.value)}
              className="block bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1 text-xs font-bold text-white focus:outline-none focus:border-amber-400"
            />
          </div>
        </div>

        {/* Status of Day's Closure */}
        <div className="flex items-center gap-3">
          {todayClosure ? (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Vendas Fechadas às {new Date(todayClosure.closedAt).toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' })}</span>
            </div>
          ) : (
            <button
              type="button"
              id="open-closure-modal-btn"
              onClick={() => {
                setPhysicalCashCounted((paymentBreakdown.fisico ?? paymentBreakdown.dinheiro ?? 0).toString());
                setIsClosureModalOpen(true);
              }}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-display font-black text-xs shadow-md shadow-amber-950/40 transition active:scale-95"
            >
              <Lock className="w-4 h-4" />
              <span>Efetuar Fecho de Caixa do Dia</span>
            </button>
          )}

          {closures.length > 0 && (
            <button
              type="button"
              onClick={() => setShowHistory(!showHistory)}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition flex items-center gap-1.5"
            >
              <FileText className="w-4 h-4 text-slate-400" />
              <span>Histórico de Fechos ({closures.length})</span>
              {showHistory ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          )}
        </div>
      </div>

      {/* Main KPI Cards: Faturação, Custos, Lucro Líquido, Bebidas */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Receita Bruta */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase">
            <span>Receita Bruta (Vendas)</span>
            <DollarSign className="w-4 h-4 text-slate-400" />
          </div>
          <div className="font-display font-black text-2xl text-slate-100 mt-1">
            {totalRevenue.toLocaleString('pt-PT')} <span className="text-xs font-medium text-slate-400">{currency}</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {validSales.length} transações realizadas
          </div>
        </div>

        {/* Custo Mercadoria */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase">
            <span>Custo Bebidas (CMV)</span>
            <Banknote className="w-4 h-4 text-slate-400" />
          </div>
          <div className="font-display font-black text-2xl text-rose-400 mt-1">
            {totalCost.toLocaleString('pt-PT')} <span className="text-xs font-medium text-slate-400">{currency}</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Preço de compra das bebidas vendidas
          </div>
        </div>

        {/* Lucro Líquido Diário - DESTAQUE PRINCIPAL */}
        <div className="bg-gradient-to-br from-emerald-950/40 via-slate-900 to-emerald-900/20 border-2 border-emerald-500/60 rounded-2xl p-4 shadow-lg shadow-emerald-950/30">
          <div className="flex items-center justify-between text-emerald-300 text-xs font-bold uppercase tracking-wider">
            <span>Lucro Líquido Hoje</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="font-display font-black text-3xl text-emerald-400 mt-1">
            +{totalProfit.toLocaleString('pt-PT')} <span className="text-xs font-bold text-emerald-300">{currency}</span>
          </div>
          <div className="text-[11px] text-emerald-300/80 mt-1 font-semibold">
            Margem Líquida: {profitMargin}% sobre vendas
          </div>
        </div>

        {/* Quantidade de Bebidas */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase">
            <span>Bebidas Vendidas</span>
            <span className="text-base">🍻</span>
          </div>
          <div className="font-display font-black text-2xl text-amber-400 mt-1">
            {totalDrinksSold} <span className="text-xs font-medium text-slate-400">unidades</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Saídas totais do balcão hoje
          </div>
        </div>
      </div>

      {/* Payment breakdown and Top Products Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Payment breakdown */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="font-display font-bold text-sm text-slate-100">
              Entradas por Forma de Pagamento
            </h4>
            <span className="text-[11px] text-amber-400 font-semibold">
              M-Pesa + e-Mola + M-Kash: {((paymentBreakdown.emola || 0) + (paymentBreakdown.mpesa || 0) + (paymentBreakdown.mkash || 0)).toLocaleString('pt-PT')} {currency}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {/* 1. Físico */}
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60 text-xs">
              <div className="flex items-center gap-2">
                <Banknote className="w-4 h-4 text-emerald-400 shrink-0" />
                <div>
                  <div className="font-semibold text-slate-200">Físico (Dinheiro)</div>
                  <div className="text-[10px] text-slate-400">Gaveta do Caixa</div>
                </div>
              </div>
              <span className="font-display font-bold text-sm text-emerald-400">
                {(paymentBreakdown.fisico ?? paymentBreakdown.dinheiro ?? 0).toLocaleString('pt-PT')} {currency}
              </span>
            </div>

            {/* 2. e-Mola */}
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60 text-xs">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-orange-400 shrink-0" />
                <div>
                  <div className="font-semibold text-slate-200">e-Mola</div>
                  <div className="text-[10px] text-orange-400/80 font-medium">Movitel</div>
                </div>
              </div>
              <span className="font-display font-bold text-sm text-orange-400">
                {(paymentBreakdown.emola ?? 0).toLocaleString('pt-PT')} {currency}
              </span>
            </div>

            {/* 3. M-Pesa */}
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60 text-xs">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-red-400 shrink-0" />
                <div>
                  <div className="font-semibold text-slate-200">M-Pesa</div>
                  <div className="text-[10px] text-red-400/80 font-medium">Vodacom</div>
                </div>
              </div>
              <span className="font-display font-bold text-sm text-red-400">
                {(paymentBreakdown.mpesa ?? paymentBreakdown.mpesa_emola ?? 0).toLocaleString('pt-PT')} {currency}
              </span>
            </div>

            {/* 4. M-Kash */}
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60 text-xs">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-amber-400 shrink-0" />
                <div>
                  <div className="font-semibold text-slate-200">M-Kash</div>
                  <div className="text-[10px] text-amber-400/80 font-medium">Tmcel</div>
                </div>
              </div>
              <span className="font-display font-bold text-sm text-amber-400">
                {(paymentBreakdown.mkash ?? 0).toLocaleString('pt-PT')} {currency}
              </span>
            </div>

            {/* 5. Cartão */}
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60 text-xs">
              <div className="flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-blue-400 shrink-0" />
                <div>
                  <div className="font-semibold text-slate-200">Cartão / POS</div>
                  <div className="text-[10px] text-slate-400">Terminal Bancário</div>
                </div>
              </div>
              <span className="font-display font-bold text-sm text-blue-400">
                {(paymentBreakdown.cartao ?? 0).toLocaleString('pt-PT')} {currency}
              </span>
            </div>

            {/* 6. Fiados */}
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60 text-xs">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-purple-400 shrink-0" />
                <div>
                  <div className="font-semibold text-slate-200">Fiados</div>
                  <div className="text-[10px] text-purple-400 font-medium">A Receber</div>
                </div>
              </div>
              <span className="font-display font-bold text-sm text-purple-400">
                {(paymentBreakdown.fiado ?? 0).toLocaleString('pt-PT')} {currency}
              </span>
            </div>
          </div>
        </div>

        {/* Top drinks ranking */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3">
          <h4 className="font-display font-bold text-sm text-slate-100 flex items-center justify-between">
            <span>Bebidas Mais Vendidas & Lucro</span>
            <span className="text-xs text-slate-400 font-normal">Top do Dia</span>
          </h4>

          {topProductsToday.length === 0 ? (
            <div className="text-center py-6 text-xs text-slate-400">
              Nenhuma venda registada para este dia.
            </div>
          ) : (
            <div className="space-y-2.5">
              {topProductsToday.map((p, idx) => {
                const maxQty = topProductsToday[0]?.quantity || 1;
                const pct = Math.round((p.quantity / maxQty) * 100);
                return (
                  <div key={p.name} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-medium text-slate-200">
                        {idx + 1}. {p.name}
                      </span>
                      <div className="text-right">
                        <span className="font-bold text-white">{p.quantity} un.</span>
                        <span className="text-emerald-400 ml-2 font-mono">(+{p.profit} {currency})</span>
                      </div>
                    </div>
                    {/* Progress Bar */}
                    <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-amber-500 to-emerald-500 rounded-full"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* History Drawer of past closures if toggled */}
      {showHistory && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3 animate-fadeIn">
          <h4 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2">
            <FileText className="w-4 h-4 text-amber-400" />
            Histórico de Fechos Diários de Caixa
          </h4>

          <div className="space-y-2 max-h-60 overflow-y-auto">
            {closures.map((c) => (
              <div
                key={c.id}
                className="p-3 bg-slate-800/60 border border-slate-700/60 rounded-xl flex flex-wrap items-center justify-between gap-3 text-xs"
              >
                <div>
                  <div className="font-bold text-slate-200">
                    Data: {c.dateStr} • Fechado por: {c.closedBy || 'Vendedor'}
                  </div>
                  <div className="text-slate-400 text-[11px] mt-0.5">
                    Receita: {c.totalRevenue} {currency} | Custo: {c.totalCost} {currency} | Lucro: +{c.totalProfit} {currency}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <a
                    href={`https://wa.me/?text=${generateWhatsAppShareText(c)}`}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2 rounded-lg bg-emerald-600/20 text-emerald-300 hover:bg-emerald-600/30 flex items-center gap-1 font-bold text-xs"
                    title="Enviar Resumo pelo WhatsApp"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>WhatsApp</span>
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Today's Sales List */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-lg">
        <div className="px-4 py-3 bg-slate-800/80 border-b border-slate-800 flex items-center justify-between">
          <h4 className="font-display font-bold text-sm text-slate-100">
            Registo de Vendas de Hoje ({validSales.length})
          </h4>
          {reversedSales.length > 0 && (
            <span className="text-xs text-rose-400">
              {reversedSales.length} estorno(s)
            </span>
          )}
        </div>

        {validSales.length === 0 ? (
          <div className="text-center py-8 text-xs text-slate-400">
            Nenhuma venda efetuada até ao momento.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-800/40 uppercase tracking-wider text-[11px] text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-4">Hora</th>
                  <th className="py-2.5 px-3">Bebidas Vendidas</th>
                  <th className="py-2.5 px-3">Pagamento</th>
                  <th className="py-2.5 px-3 text-right">Total Faturado</th>
                  <th className="py-2.5 px-3 text-right">Lucro Desta Venda</th>
                  <th className="py-2.5 px-4 text-center">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-sans">
                {validSales.map((sale) => (
                  <tr key={sale.id} className="hover:bg-slate-800/30 transition">
                    <td className="py-2.5 px-4 font-mono text-slate-400">
                      {sale.timeStr}
                    </td>
                    <td className="py-2.5 px-3 font-semibold text-slate-200">
                      {sale.items.map((i) => `${i.quantity}x ${i.productName}`).join(', ')}
                      {sale.customerName && (
                        <span className="text-[11px] text-purple-300 block font-normal">
                          Cliente: <strong className="text-white font-semibold">{sale.customerName}</strong>
                          {sale.customerPhone ? ` (${sale.customerPhone})` : ''}
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 px-3">
                      {(() => {
                        const norm = normalizePaymentMethod(sale.paymentMethod);
                        const cfg = PAYMENT_CONFIGS[norm];
                        const isUnpaid = sale.paymentMethod === 'fiado' && sale.isPaid !== true;
                        return (
                          <div className="flex flex-col gap-0.5">
                            <span className={`px-2 py-0.5 rounded-md text-[11px] font-bold border inline-block ${cfg?.badgeBg || 'bg-slate-800'} ${cfg?.badgeBorder || 'border-slate-700'} ${cfg?.badgeText || 'text-slate-300'}`}>
                              {cfg?.shortLabel || sale.paymentMethod}
                            </span>
                            {sale.paymentMethod === 'fiado' && (
                              <span className={`text-[10px] font-bold ${isUnpaid ? 'text-purple-400' : 'text-emerald-400'}`}>
                                {isUnpaid ? '• Não Pago' : '• Liquidado'}
                              </span>
                            )}
                          </div>
                        );
                      })()}
                    </td>
                    <td className="py-2.5 px-3 text-right font-display font-bold text-amber-400 text-sm">
                      {sale.totalAmount} {currency}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono text-emerald-400 font-bold">
                      +{sale.totalProfit} {currency}
                    </td>
                    <td className="py-2.5 px-4 text-center">
                      <button
                        type="button"
                        onClick={() => {
                          if (confirm('Deseja estornar esta venda? O valor será retirado e o stock devolvido.')) {
                            onReverseSale(sale.id);
                          }
                        }}
                        className="px-2 py-1 rounded bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-300 text-[11px] transition flex items-center gap-1 mx-auto"
                        title="Estornar Venda"
                      >
                        <RotateCcw className="w-3 h-3" />
                        <span>Estornar</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modal: Fecho de Caixa Diário */}
      {isClosureModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <h3 className="font-display font-bold text-lg text-slate-100 flex items-center gap-2">
                <Lock className="w-5 h-5 text-amber-400" />
                Fechar Vendas Diárias & Caixa do Bar
              </h3>
              <button
                onClick={() => setIsClosureModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs">
              {/* Summary to Close */}
              <div className="grid grid-cols-2 gap-2 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                <div>
                  <span className="text-slate-400">Total Vendas (Receita):</span>
                  <div className="font-display font-extrabold text-base text-white">
                    {totalRevenue.toLocaleString('pt-PT')} {currency}
                  </div>
                </div>
                <div>
                  <span className="text-slate-400">Lucro Líquido do Dia:</span>
                  <div className="font-display font-extrabold text-base text-emerald-400">
                    +{totalProfit.toLocaleString('pt-PT')} {currency}
                  </div>
                </div>
                <div className="col-span-2 pt-1 text-slate-400">
                  Total de bebidas servidas hoje:{' '}
                  <span className="text-amber-400 font-bold">{totalDrinksSold} unidades</span>
                </div>
              </div>

              {/* Physical Cash verification */}
              <div className="p-3 bg-slate-800/40 rounded-xl border border-slate-700/60 space-y-2">
                <label className="block font-semibold text-slate-200">
                  Conferência de Dinheiro Físico (Gaveta)
                </label>
                <div className="flex items-center justify-between text-slate-400">
                  <span>Dinheiro físico esperado pelas vendas:</span>
                  <span className="font-bold text-emerald-400 font-mono">
                    {paymentBreakdown.fisico ?? paymentBreakdown.dinheiro ?? 0} {currency}
                  </span>
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">
                    Valor contado fisicamente na gaveta:
                  </label>
                  <input
                    type="number"
                    step="any"
                    value={physicalCashCounted}
                    onChange={(e) => setPhysicalCashCounted(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-base font-bold text-white outline-none focus:border-amber-400 font-mono"
                  />
                </div>

                {physicalCashCounted !== '' && (() => {
                  const expected = paymentBreakdown.fisico ?? paymentBreakdown.dinheiro ?? 0;
                  const diff = parseFloat(physicalCashCounted) - expected;
                  return (
                    <div className="text-[11px] font-semibold pt-1">
                      {diff === 0 ? (
                        <span className="text-emerald-400">✔ Caixa físico bate certo! Nenhuma diferença.</span>
                      ) : diff > 0 ? (
                        <span className="text-blue-400">
                          Sobra de caixa: +{diff.toFixed(2)} {currency}
                        </span>
                      ) : (
                        <span className="text-rose-400">
                          Atenção: Falta/Quebra de caixa: {diff.toFixed(2)} {currency}
                        </span>
                      )}
                    </div>
                  );
                })()}
              </div>

              {/* Digital Wallets Check for Mozambique */}
              <div className="p-3 bg-slate-800/40 rounded-xl border border-slate-700/60 space-y-2 text-xs">
                <span className="font-semibold text-slate-300 block">
                  Conferência de Carteiras Móveis & POS
                </span>
                <div className="grid grid-cols-3 gap-2">
                  <div className="p-2 rounded-lg bg-orange-950/30 border border-orange-500/30">
                    <span className="text-[10px] text-orange-400 font-bold block">e-Mola (Movitel)</span>
                    <span className="text-xs font-mono font-bold text-orange-200">
                      {(paymentBreakdown.emola ?? 0).toLocaleString('pt-PT')} {currency}
                    </span>
                  </div>
                  <div className="p-2 rounded-lg bg-red-950/30 border border-red-500/30">
                    <span className="text-[10px] text-red-400 font-bold block">M-Pesa (Vodacom)</span>
                    <span className="text-xs font-mono font-bold text-red-200">
                      {(paymentBreakdown.mpesa ?? paymentBreakdown.mpesa_emola ?? 0).toLocaleString('pt-PT')} {currency}
                    </span>
                  </div>
                  <div className="p-2 rounded-lg bg-amber-950/30 border border-amber-500/30">
                    <span className="text-[10px] text-amber-400 font-bold block">M-Kash (Tmcel)</span>
                    <span className="text-xs font-mono font-bold text-amber-200">
                      {(paymentBreakdown.mkash ?? 0).toLocaleString('pt-PT')} {currency}
                    </span>
                  </div>
                </div>
              </div>

              {/* Closure Person & Notes */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">
                    Nome do Vendedor / Responsável
                  </label>
                  <input
                    type="text"
                    placeholder="Ex: Carlos, Ana..."
                    value={closedBy}
                    onChange={(e) => setClosedBy(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">
                    Observações do Fecho
                  </label>
                  <input
                    type="text"
                    placeholder="Ex: Turno da noite sem incidentes..."
                    value={closureNotes}
                    onChange={(e) => setClosureNotes(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setIsClosureModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-medium hover:bg-slate-700"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  id="submit-cash-closure-btn"
                  onClick={handleConfirmClosure}
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-display font-bold shadow-md shadow-amber-950/40 flex items-center justify-center gap-2"
                >
                  <Lock className="w-4 h-4" />
                  <span>Confirmar e Fechar Caixa do Dia</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
