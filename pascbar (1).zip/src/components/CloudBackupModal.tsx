import React, { useState } from 'react';
import { BarSettings, AppDataBackup } from '../types';
import { cloudSyncManager, CloudSyncState } from '../services/cloudSync';
import { storageService } from '../services/storage';
import { 
  Cloud, 
  CloudUpload, 
  CloudDownload, 
  Copy, 
  Check, 
  Smartphone, 
  AlertCircle, 
  Download, 
  Upload, 
  RefreshCw, 
  Save, 
  X, 
  ShieldCheck, 
  Wifi, 
  WifiOff, 
  Share2,
  Trash2
} from 'lucide-react';

interface CloudBackupModalProps {
  settings: BarSettings;
  syncState: CloudSyncState;
  onClose: () => void;
  onUpdateSettings: (newSettings: BarSettings) => void;
  onDataRestored: () => void;
  onClearAllRecords?: () => void;
}

export const CloudBackupModal: React.FC<CloudBackupModalProps> = ({
  settings,
  syncState,
  onClose,
  onUpdateSettings,
  onDataRestored,
  onClearAllRecords,
}) => {
  const [restoreCodeInput, setRestoreCodeInput] = useState('');
  const [isRestoring, setIsRestoring] = useState(false);
  const [restoreMessage, setRestoreMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);
  const [isManualSyncing, setIsManualSyncing] = useState(false);

  // Settings edit state
  const [editBarName, setEditBarName] = useState(settings.barName);
  const [editCurrency, setEditCurrency] = useState(settings.currency);
  const [editBackupCode, setEditBackupCode] = useState(settings.backupCode);
  const [editPhone, setEditPhone] = useState(settings.ownerPhone || '');
  const [settingsSavedToast, setSettingsSavedToast] = useState(false);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(settings.backupCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleManualSync = async () => {
    setIsManualSyncing(true);
    const result = await cloudSyncManager.syncNow();
    setIsManualSyncing(false);
    if (result.success) {
      alert('Sincronização na nuvem concluída com sucesso!');
    } else {
      alert(`Aviso: ${result.message}`);
    }
  };

  const handleRestoreFromCloud = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!restoreCodeInput.trim()) {
      alert('Insira o código do bar para recuperar os dados.');
      return;
    }

    const confirmMsg =
      'Atenção: Ao restaurar os dados da nuvem, todos os registos deste aparelho serão substituídos pelo backup recuperado. Deseja continuar?';
    if (!confirm(confirmMsg)) return;

    setIsRestoring(true);
    setRestoreMessage(null);

    const result = await cloudSyncManager.restoreFromCloud(restoreCodeInput);
    setIsRestoring(false);

    if (result.success) {
      setRestoreMessage({ type: 'success', text: result.message });
      onDataRestored();
      setTimeout(() => {
        onClose();
      }, 2000);
    } else {
      setRestoreMessage({ type: 'error', text: result.message });
    }
  };

  const handleDownloadFileBackup = () => {
    const backupData = storageService.getFullBackup();
    const jsonStr = JSON.stringify(backupData, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pascbar_backup_${settings.backupCode}_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleUploadFileBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string) as AppDataBackup;
        if (parsed && parsed.products) {
          if (confirm('Deseja restaurar os dados deste ficheiro de backup?')) {
            const ok = storageService.restoreFromBackup(parsed);
            if (ok) {
              alert('Dados restaurados com sucesso do ficheiro!');
              onDataRestored();
              onClose();
            } else {
              alert('Erro ao processar ficheiro de backup.');
            }
          }
        } else {
          alert('Ficheiro inválido. Certifique-se de que é um backup do PascBar.');
        }
      } catch (err) {
        alert('Erro ao ler ficheiro JSON de backup.');
      }
    };
    reader.readAsText(file);
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: BarSettings = {
      ...settings,
      barName: editBarName.trim() || 'PascBar',
      currency: editCurrency.trim() || 'MT',
      backupCode: editBackupCode.trim().toUpperCase(),
      ownerPhone: editPhone.trim() || undefined,
    };
    onUpdateSettings(updated);
    setSettingsSavedToast(true);
    setTimeout(() => setSettingsSavedToast(false), 2500);
  };

  const shareCodeText = encodeURIComponent(
    `🍻 *CÓDIGO DE RECUPERAÇÃO DO MEU BAR (PascBar)*\n\n🔑 Código: *${settings.backupCode}*\n🏠 Bar: ${settings.barName}\n\n_Guarde este código para restaurar todos os dados caso perca o telemóvel!_`
  );

  return (
    <div
      id="cloud-backup-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="cloud-backup-dialog"
        className="w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden text-slate-100 flex flex-col max-h-[95vh]"
      >
        {/* Header */}
        <div className="bg-slate-800/90 px-6 py-4 border-b border-slate-700/60 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="p-2.5 rounded-xl bg-blue-500/20 text-blue-400 border border-blue-500/30">
              <Cloud className="w-6 h-6" />
            </span>
            <div>
              <h3 className="font-display font-bold text-lg text-slate-100">
                Sincronização na Nuvem & Recuperação
              </h3>
              <p className="text-xs text-slate-400">
                Proteja os dados do bar caso perca ou mude de telemóvel
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-700 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6 overflow-y-auto flex-1 text-xs">
          {/* Connection Status Pill */}
          <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-800/50 border border-slate-700/70">
            <div className="flex items-center gap-2.5">
              {syncState.isOnline ? (
                <span className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse" />
              ) : (
                <span className="w-3 h-3 rounded-full bg-amber-500" />
              )}
              <div>
                <span className="font-bold text-slate-200">
                  {syncState.isOnline ? 'Internet Conectada' : 'Modo Offline (Sem Internet)'}
                </span>
                <p className="text-[11px] text-slate-400">
                  {syncState.lastSyncTime
                    ? `Última sincronização na nuvem: ${syncState.lastSyncTime}`
                    : 'Ainda não sincronizado na nuvem'}
                </p>
              </div>
            </div>

            <button
              type="button"
              id="sync-now-cloud-btn"
              onClick={handleManualSync}
              disabled={isManualSyncing || !syncState.isOnline}
              className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 disabled:text-slate-500 text-white font-bold transition flex items-center gap-1.5"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isManualSyncing ? 'animate-spin' : ''}`} />
              <span>{isManualSyncing ? 'Sincronizando...' : 'Sincronizar Agora'}</span>
            </button>
          </div>

          {/* Section 1: Unique Bar Backup Code (Primary Recovery Mechanism) */}
          <div className="bg-gradient-to-br from-amber-950/30 via-slate-800/60 to-slate-900 border-2 border-amber-500/60 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-display font-bold text-sm text-amber-300 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                O Seu Código Único de Recuperação na Nuvem
              </span>
              <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300">
                Guarde este código
              </span>
            </div>

            <p className="text-slate-300 text-xs leading-relaxed">
              Caso perca o telemóvel, caia água ou mude de aparelho, basta abrir o PascBar no novo telemóvel e digitar este código para recuperar instantaneamente todas as bebidas, vendas, fechos e lucros!
            </p>

            <div className="flex items-center gap-2 bg-slate-950 p-3 rounded-xl border border-amber-500/40">
              <span className="font-display font-black text-2xl text-amber-400 tracking-wider flex-1 text-center font-mono">
                {settings.backupCode}
              </span>
              <button
                type="button"
                id="copy-cloud-code-btn"
                onClick={handleCopyCode}
                className="px-3 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold flex items-center gap-1.5 transition"
              >
                {copiedCode ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copiedCode ? 'Copiado!' : 'Copiar'}</span>
              </button>

              <a
                href={`https://wa.me/?text=${shareCodeText}`}
                target="_blank"
                rel="noreferrer"
                className="px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center gap-1.5 transition"
                title="Guardar no WhatsApp"
              >
                <Share2 className="w-4 h-4" />
                <span>Salvar WhatsApp</span>
              </a>
            </div>
          </div>

          {/* Section 2: Lost Phone Recovery Flow (RESTAURAR) */}
          <div className="bg-slate-800/40 border border-slate-700/70 rounded-2xl p-4 space-y-3">
            <h4 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-emerald-400" />
              Perdeu o Telemóvel? Recuperar Dados da Nuvem
            </h4>
            <p className="text-slate-400 text-xs">
              Se está a usar um telemóvel novo ou substituto, insira o Código de Recuperação do seu bar antigo:
            </p>

            <form onSubmit={handleRestoreFromCloud} className="flex gap-2">
              <input
                type="text"
                id="restore-cloud-code-input"
                placeholder="Ex: PASC-7821"
                value={restoreCodeInput}
                onChange={(e) => setRestoreCodeInput(e.target.value.toUpperCase())}
                className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-base font-mono font-bold text-white uppercase placeholder-slate-500 focus:border-emerald-400 outline-none"
              />
              <button
                type="submit"
                id="submit-cloud-restore-btn"
                disabled={isRestoring || !restoreCodeInput.trim()}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 disabled:text-slate-500 text-white font-display font-bold transition flex items-center gap-1.5 shadow"
              >
                <CloudDownload className={`w-4 h-4 ${isRestoring ? 'animate-bounce' : ''}`} />
                <span>{isRestoring ? 'Recuperando...' : 'Recuperar Bar na Nuvem'}</span>
              </button>
            </form>

            {restoreMessage && (
              <div
                className={`p-3 rounded-xl flex items-center gap-2 text-xs ${
                  restoreMessage.type === 'success'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : 'bg-red-500/20 text-red-300 border border-red-500/40'
                }`}
              >
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{restoreMessage.text}</span>
              </div>
            )}
          </div>

          {/* Section 3: File Backup (JSON Export / Import) */}
          <div className="bg-slate-800/40 border border-slate-700/70 rounded-2xl p-4 space-y-3">
            <h4 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2">
              <Download className="w-4 h-4 text-blue-400" />
              Backup Físico em Ficheiro (.JSON)
            </h4>
            <p className="text-slate-400 text-xs">
              Também pode descarregar um ficheiro com todo o histórico do seu bar para o seu computador ou pen drive:
            </p>

            <div className="flex flex-wrap gap-3">
              <button
                type="button"
                id="download-backup-file-btn"
                onClick={handleDownloadFileBackup}
                className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-medium text-xs flex items-center gap-1.5 transition"
              >
                <Download className="w-4 h-4 text-amber-400" />
                <span>Descarregar Ficheiro de Backup</span>
              </button>

              <label className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-medium text-xs flex items-center gap-1.5 cursor-pointer transition">
                <Upload className="w-4 h-4 text-emerald-400" />
                <span>Restaurar de Ficheiro (.JSON)</span>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleUploadFileBackup}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          {/* Section 4: General Settings (Bar Name, Currency, etc.) */}
          <form onSubmit={handleSaveSettings} className="bg-slate-800/40 border border-slate-700/70 rounded-2xl p-4 space-y-3">
            <h4 className="font-display font-bold text-sm text-slate-100 flex items-center justify-between">
              <span>Configurações Gerais do Bar</span>
              {settingsSavedToast && (
                <span className="text-emerald-400 font-bold flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" /> Salvo com sucesso!
                </span>
              )}
            </h4>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-400 mb-1">Nome do Bar</label>
                <input
                  type="text"
                  value={editBarName}
                  onChange={(e) => setEditBarName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Moeda Utilizada</label>
                <input
                  type="text"
                  placeholder="Ex: MT, MZN, KZ, R$, €..."
                  value={editCurrency}
                  onChange={(e) => setEditCurrency(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white outline-none focus:border-amber-400 font-bold"
                />
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold flex items-center gap-1.5 transition"
              >
                <Save className="w-4 h-4" />
                <span>Guardar Configurações</span>
              </button>
            </div>
          </form>

          {/* Section 5: Reset All Data to Start Fresh */}
          {onClearAllRecords && (
            <div className="bg-rose-950/20 border border-rose-900/40 rounded-2xl p-4 space-y-2">
              <h4 className="font-display font-bold text-sm text-rose-300 flex items-center gap-2">
                <Trash2 className="w-4 h-4 text-rose-400" />
                Zerar Todos os Registos do Bar
              </h4>
              <p className="text-slate-400 text-xs leading-relaxed">
                Deseja limpar todos os produtos, vendas, fechos de caixa e despesas para recomeçar o bar com a sua própria lista limpa? Esta ação não pode ser desfeita.
              </p>
              <button
                type="button"
                id="modal-reset-data-btn"
                onClick={() => {
                  if (confirm('Tem certeza absoluta que deseja apagar todos os registos do bar e começar com o sistema completamente limpo?')) {
                    onClearAllRecords();
                    onClose();
                  }
                }}
                className="px-4 py-2 rounded-xl bg-rose-900/60 hover:bg-rose-800 text-rose-200 border border-rose-700/60 font-bold text-xs flex items-center gap-1.5 transition active:scale-95"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Limpar Todos os Registos (Começar do Zero)</span>
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-800/90 px-6 py-3 border-t border-slate-700/60 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-700 text-slate-200 font-bold text-xs hover:bg-slate-600 transition"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
