import React, { useState, useEffect } from 'react';
import { Product, PaymentMethod } from '../types';
import { soundFX } from '../services/audio';
import { PAYMENT_CONFIGS, normalizePaymentMethod } from '../utils/payment';
import { X, Check, DollarSign, Plus, Minus, Tag, Zap, AlertTriangle, Smartphone, CreditCard, Banknote, Clock, User, Phone } from 'lucide-react';

interface PriceConfirmModalProps {
  product: Product;
  currency: string;
  initialPaymentMethod?: PaymentMethod;
  existingCustomers?: string[];
  onConfirm: (data: {
    quantity: number;
    unitPrice: number;
    paymentMethod: PaymentMethod;
    customerName?: string;
    customerPhone?: string;
    dueDate?: string;
    notes?: string;
  }) => void;
  onClose: () => void;
}

export const PriceConfirmModal: React.FC<PriceConfirmModalProps> = ({
  product,
  currency,
  initialPaymentMethod = 'fisico',
  existingCustomers = [],
  onConfirm,
  onClose,
}) => {
  const [quantity, setQuantity] = useState<number>(1);
  const [unitPrice, setUnitPrice] = useState<number>(product.sellPrice);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(initialPaymentMethod);
  const [customerName, setCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [dueDate, setDueDate] = useState<string>('');
  const [notes, setNotes] = useState<string>('');

  // Calculate profit and subtotal live
  const subtotal = quantity * unitPrice;
  const totalCost = quantity * product.costPrice;
  const totalProfit = subtotal - totalCost;
  const profitMargin = subtotal > 0 ? Math.round((totalProfit / subtotal) * 100) : 0;
  const isOutOfStock = product.currentStock <= 0;
  const hasExceededStock = quantity > product.currentStock;

  // Handle hotkeys (Enter to confirm, Escape to cancel)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'Enter' && !e.shiftKey) {
        handleConfirm();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [quantity, unitPrice, paymentMethod, customerName, notes]);

  const handleConfirm = () => {
    if (unitPrice <= 0) {
      alert('Por favor defina um preço de venda válido.');
      return;
    }
    if (quantity <= 0) {
      alert('Quantidade deve ser pelo menos 1.');
      return;
    }
    if (paymentMethod === 'fiado' && !customerName.trim()) {
      alert('⚠️ Para registar como Fiado / Dívida, é obrigatório informar o Nome do Cliente para controlo na caderneta.');
      return;
    }
    soundFX.playSaleChime();
    onConfirm({
      quantity,
      unitPrice,
      paymentMethod,
      customerName: customerName.trim() || undefined,
      customerPhone: customerPhone.trim() || undefined,
      dueDate: dueDate.trim() || undefined,
      notes,
    });
  };

  const handlePriceDelta = (delta: number) => {
    soundFX.playClick();
    setUnitPrice((prev) => Math.max(0, prev + delta));
  };

  return (
    <div
      id="price-confirm-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="price-confirm-dialog"
        className="w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden text-slate-100 flex flex-col max-h-[95vh]"
      >
        {/* Header */}
        <div className="bg-slate-800/90 px-5 py-4 border-b border-slate-700/60 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xl border border-amber-500/30">
              🍺
            </span>
            <div>
              <h3 className="font-display font-bold text-lg text-slate-100 leading-tight">
                {product.name}
              </h3>
              <p className="text-xs text-slate-400">
                {product.volume || product.category} • Stock Atual: <span className={product.currentStock <= product.minStockAlert ? 'text-amber-400 font-bold' : 'text-emerald-400 font-bold'}>{product.currentStock} un.</span>
              </p>
            </div>
          </div>
          <button
            id="close-price-modal-btn"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-700/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Stock warning if empty or low */}
        {product.currentStock <= 0 && (
          <div className="bg-red-500/20 border-b border-red-500/40 px-5 py-2 text-red-300 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0 text-red-400" />
            <span><strong>Atenção:</strong> Bebida com stock esgotado! A venda será registada com stock negativo.</span>
          </div>
        )}

        {/* Body Form */}
        <div className="p-5 space-y-4 overflow-y-auto flex-1">
          {/* Quantity Selector */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
              Quantidade de Bebidas
            </label>
            <div className="flex items-center gap-3">
              <button
                type="button"
                id="qty-minus-btn"
                onClick={() => {
                  soundFX.playClick();
                  setQuantity((q) => Math.max(1, q - 1));
                }}
                className="w-12 h-12 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 flex items-center justify-center font-bold text-xl border border-slate-700 transition"
              >
                <Minus className="w-5 h-5" />
              </button>

              <div className="flex-1 flex items-center justify-center bg-slate-800/80 border border-slate-700 rounded-xl h-12 px-4">
                <input
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-full text-center font-display font-extrabold text-2xl text-white bg-transparent outline-none"
                />
                <span className="text-xs text-slate-400 font-medium ml-1">un.</span>
              </div>

              <button
                type="button"
                id="qty-plus-btn"
                onClick={() => {
                  soundFX.playClick();
                  setQuantity((q) => q + 1);
                }}
                className="w-12 h-12 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 flex items-center justify-center font-bold text-xl border border-slate-700 transition"
              >
                <Plus className="w-5 h-5" />
              </button>
            </div>

            {/* Quick quantity shortcuts for bar service (1, 2, 3, 6, 12, 24) */}
            <div className="flex gap-2 mt-2">
              {[1, 2, 3, 4, 6, 12, 24].map((num) => (
                <button
                  key={num}
                  type="button"
                  onClick={() => {
                    soundFX.playClick();
                    setQuantity(num);
                  }}
                  className={`flex-1 py-1.5 text-xs font-semibold rounded-lg border transition ${
                    quantity === num
                      ? 'bg-amber-500/30 border-amber-500 text-amber-300'
                      : 'bg-slate-800/60 border-slate-700/60 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                  }`}
                >
                  {num === 6 ? '6 (Meia)' : num === 24 ? '24 (Grade)' : `${num}x`}
                </button>
              ))}
            </div>
          </div>

          {/* Price Dictation / Confirmation Section */}
          <div className="bg-slate-800/40 p-4 rounded-xl border border-slate-700/60 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5 text-amber-400" />
                  Preço Unitário Cobrado
                </span>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Preço Padrão: <span className="text-slate-300 font-medium">{product.sellPrice} {currency}</span> • Custo: <span className="text-slate-400">{product.costPrice} {currency}</span>
                </p>
              </div>
              <button
                type="button"
                onClick={() => setUnitPrice(product.sellPrice)}
                className="text-[11px] px-2.5 py-1 rounded bg-slate-700/80 hover:bg-slate-700 text-amber-400 font-medium transition"
              >
                Restaurar Padrão
              </button>
            </div>

            {/* Input with direct manual dictation */}
            <div className="relative flex items-center">
              <div className="absolute left-4 font-display font-bold text-lg text-amber-400">
                {currency}
              </div>
              <input
                id="dictated-price-input"
                type="number"
                step="any"
                min="0"
                value={unitPrice}
                onChange={(e) => setUnitPrice(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-800 border-2 border-amber-500/60 focus:border-amber-400 rounded-xl pl-14 pr-4 py-2.5 font-display font-extrabold text-2xl text-amber-300 outline-none text-right transition"
              />
            </div>

            {/* Fast adjustments buttons (+5, +10, -5, -10, etc.) */}
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => handlePriceDelta(-10)}
                className="flex-1 py-1 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-rose-300 border border-slate-700"
              >
                -10
              </button>
              <button
                type="button"
                onClick={() => handlePriceDelta(-5)}
                className="flex-1 py-1 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-rose-300 border border-slate-700"
              >
                -5
              </button>
              <button
                type="button"
                onClick={() => handlePriceDelta(5)}
                className="flex-1 py-1 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700"
              >
                +5
              </button>
              <button
                type="button"
                onClick={() => handlePriceDelta(10)}
                className="flex-1 py-1 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700"
              >
                +10
              </button>
              <button
                type="button"
                onClick={() => handlePriceDelta(20)}
                className="flex-1 py-1 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700"
              >
                +20
              </button>
            </div>
          </div>

          {/* Payment Method */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400">
                Forma de Pagamento
              </label>
              <span className="text-[11px] text-amber-400 font-medium">
                {paymentMethod === 'fisico' && '💵 Dinheiro em Caixa'}
                {paymentMethod === 'emola' && '🟠 e-Mola (Movitel)'}
                {paymentMethod === 'mpesa' && '🔴 M-Pesa (Vodacom)'}
                {paymentMethod === 'mkash' && '🟡 M-Kash (Tmcel)'}
                {paymentMethod === 'cartao' && '💳 Cartão / POS Bancário'}
                {paymentMethod === 'fiado' && '⏳ Fiado / A Receber'}
              </span>
            </div>

            {/* Main 4 payment methods: Fisico, e-Mola, M-Pesa, M-Kash */}
            <div className="grid grid-cols-2 gap-2">
              {/* 1. Fisico */}
              <button
                type="button"
                id="pay-fisico-btn"
                onClick={() => {
                  soundFX.playClick();
                  setPaymentMethod('fisico');
                }}
                className={`py-3 px-3.5 rounded-xl border flex items-center justify-between transition active:scale-98 ${
                  paymentMethod === 'fisico' || paymentMethod === 'dinheiro'
                    ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 shadow-md shadow-emerald-950/40 ring-1 ring-emerald-500/50'
                    : 'bg-slate-800/80 border-slate-700/80 text-slate-300 hover:bg-slate-800 hover:border-emerald-500/30'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center text-emerald-400 border border-emerald-500/30">
                    <Banknote className="w-4 h-4" />
                  </div>
                  <div className="text-left">
                    <div className="text-xs font-bold text-slate-100">Físico</div>
                    <div className="text-[10px] text-slate-400">Dinheiro / Caixa</div>
                  </div>
                </div>
                {(paymentMethod === 'fisico' || paymentMethod === 'dinheiro') && (
                  <Check className="w-4 h-4 text-emerald-400" />
                )}
              </button>

              {/* 2. e-Mola */}
              <button
                type="button"
                id="pay-emola-btn"
                onClick={() => {
                  soundFX.playClick();
                  setPaymentMethod('emola');
                }}
                className={`py-3 px-3.5 rounded-xl border flex items-center justify-between transition active:scale-98 ${
                  paymentMethod === 'emola'
                    ? 'bg-orange-500/20 border-orange-500 text-orange-300 shadow-md shadow-orange-950/40 ring-1 ring-orange-500/50'
                    : 'bg-slate-800/80 border-slate-700/80 text-slate-300 hover:bg-slate-800 hover:border-orange-500/30'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-orange-500/20 flex items-center justify-center text-orange-400 border border-orange-500/30">
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <div className="text-left">
                    <div className="text-xs font-bold text-slate-100">e-Mola</div>
                    <div className="text-[10px] text-orange-400/80 font-medium">Movitel</div>
                  </div>
                </div>
                {paymentMethod === 'emola' && (
                  <Check className="w-4 h-4 text-orange-400" />
                )}
              </button>

              {/* 3. M-Pesa */}
              <button
                type="button"
                id="pay-mpesa-btn"
                onClick={() => {
                  soundFX.playClick();
                  setPaymentMethod('mpesa');
                }}
                className={`py-3 px-3.5 rounded-xl border flex items-center justify-between transition active:scale-98 ${
                  paymentMethod === 'mpesa' || paymentMethod === 'mpesa_emola'
                    ? 'bg-red-500/20 border-red-500 text-red-300 shadow-md shadow-red-950/40 ring-1 ring-red-500/50'
                    : 'bg-slate-800/80 border-slate-700/80 text-slate-300 hover:bg-slate-800 hover:border-red-500/30'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-red-500/20 flex items-center justify-center text-red-400 border border-red-500/30">
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <div className="text-left">
                    <div className="text-xs font-bold text-slate-100">M-Pesa</div>
                    <div className="text-[10px] text-red-400/80 font-medium">Vodacom</div>
                  </div>
                </div>
                {(paymentMethod === 'mpesa' || paymentMethod === 'mpesa_emola') && (
                  <Check className="w-4 h-4 text-red-400" />
                )}
              </button>

              {/* 4. M-Kash */}
              <button
                type="button"
                id="pay-mkash-btn"
                onClick={() => {
                  soundFX.playClick();
                  setPaymentMethod('mkash');
                }}
                className={`py-3 px-3.5 rounded-xl border flex items-center justify-between transition active:scale-98 ${
                  paymentMethod === 'mkash'
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-md shadow-amber-950/40 ring-1 ring-amber-500/50'
                    : 'bg-slate-800/80 border-slate-700/80 text-slate-300 hover:bg-slate-800 hover:border-amber-500/30'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-amber-500/20 flex items-center justify-center text-amber-400 border border-amber-500/30">
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <div className="text-left">
                    <div className="text-xs font-bold text-slate-100">M-Kash</div>
                    <div className="text-[10px] text-amber-400/80 font-medium">Tmcel</div>
                  </div>
                </div>
                {paymentMethod === 'mkash' && (
                  <Check className="w-4 h-4 text-amber-400" />
                )}
              </button>
            </div>

            {/* Secondary options: Cartão & Fiado */}
            <div className="grid grid-cols-2 gap-2 mt-2">
              <button
                type="button"
                id="pay-card-btn"
                onClick={() => {
                  soundFX.playClick();
                  setPaymentMethod('cartao');
                }}
                className={`py-2 px-3 rounded-xl border flex items-center gap-2 transition text-left ${
                  paymentMethod === 'cartao'
                    ? 'bg-blue-500/20 border-blue-500 text-blue-300 shadow-sm'
                    : 'bg-slate-800/70 border-slate-700/70 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <CreditCard className="w-4 h-4 text-blue-400 shrink-0" />
                <span className="text-xs font-medium">Cartão / POS</span>
              </button>

              <button
                type="button"
                id="pay-fiado-btn"
                onClick={() => {
                  soundFX.playClick();
                  setPaymentMethod('fiado');
                }}
                className={`py-2 px-3 rounded-xl border flex items-center gap-2 transition text-left ${
                  paymentMethod === 'fiado'
                    ? 'bg-purple-500/20 border-purple-500 text-purple-300 shadow-sm'
                    : 'bg-slate-800/70 border-slate-700/70 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <Clock className="w-4 h-4 text-purple-400 shrink-0" />
                <span className="text-xs font-medium">Fiado (Pendente)</span>
              </button>
            </div>

            {/* Customer name & details if Fiado */}
            {paymentMethod === 'fiado' && (
              <div className="mt-3 p-3 bg-purple-950/20 border border-purple-500/40 rounded-xl space-y-2.5 animate-fadeIn">
                <div className="flex items-center justify-between text-xs font-bold text-purple-300">
                  <span className="flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-purple-400" />
                    Registar Dívida / Fiado na Caderneta
                  </span>
                  <span className="text-[10px] text-amber-400">Nome Obrigatório</span>
                </div>

                <div>
                  <input
                    type="text"
                    required
                    placeholder="Nome do cliente (obrigatório, ex: Carlos Mabote, Nelson)..."
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full bg-slate-900 border border-purple-500/60 rounded-xl px-3 py-2 text-sm text-white placeholder-slate-400 focus:outline-none focus:border-purple-400"
                  />

                  {/* Customer suggestions */}
                  {existingCustomers.length > 0 && !customerName && (
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      <span className="text-[10px] text-slate-400 self-center mr-1">Sugerir:</span>
                      {existingCustomers.slice(0, 5).map((name) => (
                        <button
                          key={name}
                          type="button"
                          onClick={() => setCustomerName(name)}
                          className="px-2 py-0.5 rounded-lg bg-slate-800 hover:bg-purple-600/30 text-purple-200 border border-slate-700 text-[11px] transition"
                        >
                          {name}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2 pt-0.5">
                  <div>
                    <label className="block text-[10px] text-slate-400 mb-1">
                      Telefone / WhatsApp (Opcional)
                    </label>
                    <input
                      type="tel"
                      placeholder="Ex: 84 123 4567"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-400"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400 mb-1">
                      Previsão de Pagamento
                    </label>
                    <input
                      type="text"
                      placeholder="Ex: Sexta-feira, Fim do mês"
                      value={dueDate}
                      onChange={(e) => setDueDate(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-400"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Live Profit Summary Box */}
          <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3 flex items-center justify-between text-xs">
            <div>
              <span className="text-slate-400">Lucro Estimado Desta Venda:</span>
              <div className="font-display font-bold text-sm text-emerald-400">
                +{totalProfit.toLocaleString('pt-PT')} {currency}
                <span className="text-slate-400 text-[11px] font-normal ml-1">
                  ({profitMargin}% de margem)
                </span>
              </div>
            </div>
            <div className="text-right">
              <span className="text-slate-400">Stock após venda:</span>
              <div className="font-display font-semibold text-slate-200">
                {product.currentStock - quantity} un.
              </div>
            </div>
          </div>
        </div>

        {/* Action Footer */}
        <div className="bg-slate-800/90 px-5 py-4 border-t border-slate-700/60 flex items-center gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-3 rounded-xl bg-slate-700/80 hover:bg-slate-700 text-slate-300 font-medium text-sm transition"
          >
            Cancelar
          </button>

          <button
            type="button"
            id="confirm-sale-submit-btn"
            onClick={handleConfirm}
            className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 active:scale-[0.99] text-white font-display font-bold text-base shadow-lg shadow-emerald-950/40 flex items-center justify-center gap-2 transition"
          >
            <Check className="w-5 h-5 text-white" />
            <span>Confirmar Venda ({subtotal.toLocaleString('pt-PT')} {currency})</span>
          </button>
        </div>
      </div>
    </div>
  );
};
