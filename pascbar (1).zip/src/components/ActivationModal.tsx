import React, { useState } from 'react';
import { LicenseState } from '../types';
import { soundFX } from '../services/audio';
import { Key, Lock, CheckCircle2, ShieldAlert, Sparkles, X, AlertTriangle } from 'lucide-react';

interface ActivationModalProps {
  license: LicenseState;
  isTrialExpired: boolean;
  daysRemaining: number;
  onActivate: (keyUsed: string) => boolean;
  onClose?: () => void;
  canDismiss?: boolean;
  onSimulateExpiry?: () => void;
  onResetTrial?: () => void;
}

// Exactly specified activation keys
const VALID_KEYS = ['lucia86&@', '193555'];

export const ActivationModal: React.FC<ActivationModalProps> = ({
  license,
  isTrialExpired,
  daysRemaining,
  onActivate,
  onClose,
  canDismiss = false,
  onSimulateExpiry,
  onResetTrial,
}) => {
  const [inputKey, setInputKey] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const handleActivateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    // Clean input without possibility of error (trim, strip accidental whitespace)
    const cleaned = inputKey.trim();

    if (!cleaned) {
      setErrorMsg('Por favor insira a chave de ativação.');
      return;
    }

    const isValid = VALID_KEYS.some((k) => k === cleaned);

    if (isValid) {
      soundFX.playSaleChime();
      setSuccessMsg('PascBar Ativado com Sucesso! Licença Vitalícia Ativa.');
      setTimeout(() => {
        onActivate(cleaned);
      }, 1200);
    } else {
      soundFX.playStockAlertBeep();
      setErrorMsg('Chave de ativação incorreta. Utilize a chave fornecida pelo administrador.');
    }
  };

  const handlePasteKey = async (sampleKey: string) => {
    setInputKey(sampleKey);
    setErrorMsg('');
  };

  return (
    <div
      id="activation-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fadeIn"
    >
      <div
        id="activation-dialog"
        className="w-full max-w-md bg-slate-900 border-2 border-amber-500/70 rounded-3xl shadow-2xl p-6 text-slate-100 relative overflow-hidden"
      >
        {/* Glow effect */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Dismiss button if trial is still active and user just opened settings */}
        {canDismiss && onClose && (
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white bg-slate-800/80"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        <div className="text-center space-y-3 pt-2">
          <div className="inline-flex p-4 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/40 shadow-lg">
            {isTrialExpired ? <Lock className="w-10 h-10" /> : <Key className="w-10 h-10" />}
          </div>

          <h2 className="font-display font-black text-2xl text-white">
            {isTrialExpired ? 'Período de Teste Terminado' : 'Ativação do PascBar'}
          </h2>

          <p className="text-xs text-slate-300 leading-relaxed px-2">
            {isTrialExpired ? (
              <span>
                A sua semana de avaliação gratuita de 7 dias do <strong>PascBar</strong> terminou.
                Para continuar a registar vendas e gerir o seu stock, insira a chave de ativação oficial.
              </span>
            ) : (
              <span>
                O seu período de avaliação gratuito está ativo ({daysRemaining} dias restantes).
                Pode ativar a licença vitalícia agora com a sua chave.
              </span>
            )}
          </p>
        </div>

        {/* Activation Form */}
        <form onSubmit={handleActivateSubmit} className="mt-6 space-y-4">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-amber-400 mb-1.5 text-center">
              Chave de Ativação
            </label>
            <div className="relative">
              <input
                type="text"
                id="activation-key-input"
                autoFocus
                placeholder="Insira a chave de ativação..."
                value={inputKey}
                onChange={(e) => setInputKey(e.target.value)}
                className="w-full bg-slate-950 border-2 border-amber-500/70 focus:border-amber-400 rounded-xl py-3 px-4 text-center font-mono font-bold text-lg text-amber-300 placeholder-slate-500 outline-none transition shadow-inner"
              />
            </div>
            <p className="text-[11px] text-slate-400 text-center mt-1">
              Chaves autorizadas: <span className="font-mono text-slate-300">lucia86&@</span> ou <span className="font-mono text-slate-300">193555</span>
            </p>
          </div>

          {/* Quick paste helper chips */}
          <div className="flex justify-center gap-2">
            <button
              type="button"
              onClick={() => handlePasteKey('lucia86&@')}
              className="text-[11px] px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 font-mono"
            >
              Inserir lucia86&@
            </button>
            <button
              type="button"
              onClick={() => handlePasteKey('193555')}
              className="text-[11px] px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 font-mono"
            >
              Inserir 193555
            </button>
          </div>

          {errorMsg && (
            <div className="p-3 bg-red-500/20 border border-red-500/40 rounded-xl text-red-300 text-xs text-center flex items-center justify-center gap-2">
              <ShieldAlert className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-3 bg-emerald-500/20 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs text-center flex items-center justify-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span className="font-bold">{successMsg}</span>
            </div>
          )}

          <button
            type="submit"
            id="submit-activation-btn"
            className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 active:scale-[0.99] text-slate-950 font-display font-black text-sm shadow-xl shadow-amber-950/50 flex items-center justify-center gap-2 transition"
          >
            <Sparkles className="w-4 h-4" />
            <span>Desbloquear e Ativar PascBar</span>
          </button>
        </form>

        {/* Development testing utilities */}
        <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-500">
          <span>Ambiente Balcão PascBar</span>
          <div className="flex gap-2">
            {onSimulateExpiry && !isTrialExpired && (
              <button
                type="button"
                onClick={onSimulateExpiry}
                className="text-amber-500/70 hover:text-amber-400 underline"
              >
                Simular Fim de 7 Dias
              </button>
            )}
            {onResetTrial && (
              <button
                type="button"
                onClick={onResetTrial}
                className="text-slate-500 hover:text-slate-300 underline"
              >
                Reiniciar Teste
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
