import React from 'react';
import { 
  Wine, 
  ShoppingBag, 
  Package, 
  TrendingUp, 
  Layers, 
  Cloud, 
  Wifi, 
  WifiOff, 
  Volume2, 
  VolumeX, 
  ShieldCheck, 
  AlertTriangle,
  Lock,
  Key,
  BookOpen
} from 'lucide-react';
import { CloudSyncState } from '../services/cloudSync';
import { LicenseState } from '../types';

export type ActiveTab = 'pos' | 'stock' | 'debts' | 'daily_report' | 'cash_flow';

interface NavbarProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  barName: string;
  backupCode: string;
  syncState: CloudSyncState;
  license: LicenseState;
  daysRemaining: number;
  isTrialExpired: boolean;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onOpenCloudModal: () => void;
  onOpenActivationModal: () => void;
  stockAlertCount: number;
  unpaidDebtsCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  onSelectTab,
  barName,
  backupCode,
  syncState,
  license,
  daysRemaining,
  isTrialExpired,
  soundEnabled,
  onToggleSound,
  onOpenCloudModal,
  onOpenActivationModal,
  stockAlertCount,
  unpaidDebtsCount = 0,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-slate-950/95 border-b border-slate-800 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-3 sm:px-6">
        {/* Top brand & system indicators */}
        <div className="flex items-center justify-between py-2.5 border-b border-slate-900 gap-2">
          {/* Logo & Bar Name */}
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center text-slate-950 shadow-md shadow-amber-950/40">
              <Wine className="w-5 h-5 fill-slate-950 stroke-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-display font-black text-xl text-white tracking-tight">
                  Pasc<span className="text-amber-400">Bar</span>
                </span>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30 uppercase">
                  POS
                </span>
              </div>
              <p className="text-[10px] text-slate-400 -mt-0.5 truncate max-w-[140px] sm:max-w-none">
                {barName} • Balcão Ágil
              </p>
            </div>
          </div>

          {/* Status Indicators & Action buttons */}
          <div className="flex items-center gap-1.5 sm:gap-2 text-xs">
            {/* Online / Offline & Cloud status pill */}
            <button
              type="button"
              id="cloud-status-nav-btn"
              onClick={onOpenCloudModal}
              className={`px-2.5 py-1.5 rounded-xl border flex items-center gap-1.5 transition text-[11px] font-semibold ${
                syncState.isOnline
                  ? 'bg-slate-900 border-slate-800 text-slate-300 hover:border-blue-500/50'
                  : 'bg-amber-950/40 border-amber-500/50 text-amber-300'
              }`}
              title="Clique para ver o Código de Backup e recuperar dados"
            >
              {syncState.isOnline ? (
                <>
                  <Cloud className="w-3.5 h-3.5 text-blue-400" />
                  <span className="hidden sm:inline">Nuvem:</span>
                  <span className="text-emerald-400 font-bold">Online</span>
                </>
              ) : (
                <>
                  <WifiOff className="w-3.5 h-3.5 text-amber-400" />
                  <span className="font-bold">Offline</span>
                </>
              )}
            </button>

            {/* Cloud Backup Code Pill */}
            <button
              type="button"
              onClick={onOpenCloudModal}
              className="hidden md:flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-[11px] font-mono text-amber-400 hover:bg-slate-850"
              title="Código de Recuperação do Bar"
            >
              <span className="text-slate-500 font-sans text-[10px]">Cód:</span>
              <span className="font-bold">{backupCode}</span>
            </button>

            {/* License Pill */}
            <button
              type="button"
              id="license-badge-nav-btn"
              onClick={onOpenActivationModal}
              className={`px-2.5 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 transition ${
                license.isActivated
                  ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/40'
                  : isTrialExpired
                  ? 'bg-red-500/20 text-red-300 border border-red-500/50 animate-pulse'
                  : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
              }`}
            >
              {license.isActivated ? (
                <>
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="hidden sm:inline">Ativado</span>
                </>
              ) : isTrialExpired ? (
                <>
                  <Lock className="w-3.5 h-3.5 text-red-400" />
                  <span>Expirado</span>
                </>
              ) : (
                <>
                  <Key className="w-3.5 h-3.5 text-amber-400" />
                  <span>Teste ({daysRemaining}d)</span>
                </>
              )}
            </button>

            {/* Sound Toggle */}
            <button
              type="button"
              onClick={onToggleSound}
              className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition"
              title={soundEnabled ? 'Som do balcão ativado' : 'Som desativado'}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-amber-400" /> : <VolumeX className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Navigation Tabs Bar */}
        <nav className="flex items-center gap-1 sm:gap-2 py-2 overflow-x-auto scrollbar-none">
          {/* 1. Vender / Balcão */}
          <button
            type="button"
            id="nav-tab-pos"
            onClick={() => onSelectTab('pos')}
            className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl font-display font-bold text-xs flex items-center justify-center gap-2 transition ${
              activeTab === 'pos'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-950/50'
                : 'bg-slate-900/60 text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Vender (Balcão)</span>
          </button>

          {/* 2. Stock & Bebidas */}
          <button
            type="button"
            id="nav-tab-stock"
            onClick={() => onSelectTab('stock')}
            className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl font-display font-bold text-xs flex items-center justify-center gap-2 transition relative ${
              activeTab === 'stock'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-950/50'
                : 'bg-slate-900/60 text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>Stock & Bebidas</span>
            {stockAlertCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-red-600 text-white text-[10px] font-bold flex items-center justify-center ml-1">
                {stockAlertCount}
              </span>
            )}
          </button>

          {/* 3. Caderneta de Fiados & Dívidas */}
          <button
            type="button"
            id="nav-tab-debts"
            onClick={() => onSelectTab('debts')}
            className={`flex-1 min-w-[135px] py-2.5 px-3 rounded-xl font-display font-bold text-xs flex items-center justify-center gap-2 transition relative ${
              activeTab === 'debts'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-950/50'
                : 'bg-slate-900/60 text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Fiados & Dívidas</span>
            {unpaidDebtsCount !== undefined && unpaidDebtsCount > 0 && (
              <span className="px-1.5 py-0.5 rounded-full bg-purple-600 text-white text-[10px] font-bold flex items-center justify-center ml-0.5 animate-pulse">
                {unpaidDebtsCount}
              </span>
            )}
          </button>

          {/* 4. Lucro Diário & Fecho */}
          <button
            type="button"
            id="nav-tab-daily"
            onClick={() => onSelectTab('daily_report')}
            className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl font-display font-bold text-xs flex items-center justify-center gap-2 transition ${
              activeTab === 'daily_report'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-950/50'
                : 'bg-slate-900/60 text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            <span>Lucro Diário & Fecho</span>
          </button>

          {/* 4. Fluxo de Caixa Mensal */}
          <button
            type="button"
            id="nav-tab-monthly"
            onClick={() => onSelectTab('cash_flow')}
            className={`flex-1 min-w-[150px] py-2.5 px-3 rounded-xl font-display font-bold text-xs flex items-center justify-center gap-2 transition ${
              activeTab === 'cash_flow'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-950/50'
                : 'bg-slate-900/60 text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Fluxo de Caixa Mensal</span>
          </button>
        </nav>
      </div>
    </header>
  );
};
