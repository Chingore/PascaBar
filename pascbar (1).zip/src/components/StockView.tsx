import React, { useState, useMemo } from 'react';
import { Product, ProductCategory } from '../types';
import { soundFX } from '../services/audio';
import { 
  Plus, 
  Search, 
  AlertTriangle, 
  Package, 
  TrendingDown, 
  ArrowUpDown, 
  Edit3, 
  Trash2, 
  Check, 
  X, 
  PlusCircle, 
  DollarSign, 
  Layers
} from 'lucide-react';

interface StockViewProps {
  products: Product[];
  currency: string;
  onAddProduct: (product: Omit<Product, 'id' | 'createdAt' | 'updatedAt' | 'totalSold'>) => void;
  onUpdateProduct: (product: Product) => void;
  onDeleteProduct: (productId: string) => void;
  onRestockProduct: (productId: string, quantityToAdd: number) => void;
  onClearAllRecords?: () => void;
}

const CATEGORIES: ProductCategory[] = [
  'Cerveja',
  'Refrigerante',
  'Cider',
  'Destilado',
  'Vinho',
  'Energético',
  'Água',
  'Petisco',
  'Outros',
];

export const StockView: React.FC<StockViewProps> = ({
  products,
  currency,
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
  onRestockProduct,
  onClearAllRecords,
}) => {
  const [search, setSearch] = useState('');
  const [filterMode, setFilterMode] = useState<'all' | 'out_of_stock' | 'low_stock' | 'top_sellers'>('all');
  
  // Modal states
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [restockProduct, setRestockProduct] = useState<Product | null>(null);
  const [restockQty, setRestockQty] = useState<number>(24);

  // Add Product Form State
  const [newProdName, setNewProdName] = useState('');
  const [newProdCategory, setNewProdCategory] = useState<ProductCategory>('Cerveja');
  const [newProdVolume, setNewProdVolume] = useState('330ml');
  const [newProdCost, setNewProdCost] = useState<number>(50);
  const [newProdSell, setNewProdSell] = useState<number>(80);
  const [newProdStock, setNewProdStock] = useState<number>(24);
  const [newProdMinAlert, setNewProdMinAlert] = useState<number>(10);

  // Aggregated Stock Stats
  const totalStockUnits = useMemo(() => products.reduce((sum, p) => sum + p.currentStock, 0), [products]);
  const totalExits = useMemo(() => products.reduce((sum, p) => sum + p.totalSold, 0), [products]);
  const totalCostValue = useMemo(() => products.reduce((sum, p) => sum + (p.currentStock * p.costPrice), 0), [products]);
  const totalSellValue = useMemo(() => products.reduce((sum, p) => sum + (p.currentStock * p.sellPrice), 0), [products]);

  const outOfStockCount = useMemo(() => products.filter((p) => p.currentStock <= 0).length, [products]);
  const lowStockCount = useMemo(() => products.filter((p) => p.currentStock > 0 && p.currentStock <= p.minStockAlert).length, [products]);

  // Filtered list
  const displayedProducts = useMemo(() => {
    return products
      .filter((p) => {
        const matchesSearch =
          p.name.toLowerCase().includes(search.toLowerCase()) ||
          p.category.toLowerCase().includes(search.toLowerCase());

        if (!matchesSearch) return false;

        if (filterMode === 'out_of_stock') return p.currentStock <= 0;
        if (filterMode === 'low_stock') return p.currentStock > 0 && p.currentStock <= p.minStockAlert;
        return true;
      })
      .sort((a, b) => {
        if (filterMode === 'top_sellers') return b.totalSold - a.totalSold;
        if (filterMode === 'out_of_stock' || filterMode === 'low_stock') return a.currentStock - b.currentStock;
        return a.name.localeCompare(b.name);
      });
  }, [products, search, filterMode]);

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProdName.trim()) {
      alert('Introduza o nome da bebida.');
      return;
    }
    if (newProdSell <= 0) {
      alert('O preço de venda deve ser maior que zero.');
      return;
    }

    onAddProduct({
      name: newProdName.trim(),
      category: newProdCategory,
      volume: newProdVolume.trim(),
      costPrice: Number(newProdCost) || 0,
      sellPrice: Number(newProdSell) || 0,
      currentStock: Number(newProdStock) || 0,
      minStockAlert: Number(newProdMinAlert) || 5,
    });

    // Reset
    setNewProdName('');
    setNewProdCost(50);
    setNewProdSell(80);
    setNewProdStock(24);
    setIsAddModalOpen(false);
  };

  const handleUpdateProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;
    onUpdateProduct(editingProduct);
    setEditingProduct(null);
  };

  const handleExecuteRestock = () => {
    if (!restockProduct || restockQty <= 0) return;
    onRestockProduct(restockProduct.id, restockQty);
    setRestockProduct(null);
  };

  return (
    <div className="space-y-4">
      {/* Metrics Row: Stock Existente, Saídas, Alertas */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Total Stock */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase">
            <span>Stock Existente</span>
            <Package className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="font-display font-black text-2xl text-emerald-400 mt-1">
            {totalStockUnits.toLocaleString('pt-PT')} <span className="text-xs font-normal text-slate-400">un.</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Valor a custo: {totalCostValue.toLocaleString('pt-PT')} {currency}
          </div>
        </div>

        {/* Total Exits */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase">
            <span>Total Saídas</span>
            <TrendingDown className="w-4 h-4 text-blue-400" />
          </div>
          <div className="font-display font-black text-2xl text-blue-400 mt-1">
            {totalExits.toLocaleString('pt-PT')} <span className="text-xs font-normal text-slate-400">vendidas</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Bebidas servidas aos clientes
          </div>
        </div>

        {/* Out of stock alert */}
        <div className={`border rounded-2xl p-4 shadow-md transition ${
          outOfStockCount > 0 
            ? 'bg-red-950/30 border-red-500/50' 
            : 'bg-slate-900 border-slate-800'
        }`}>
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase">
            <span>Fim de Stock</span>
            <AlertTriangle className={`w-4 h-4 ${outOfStockCount > 0 ? 'text-red-400' : 'text-slate-500'}`} />
          </div>
          <div className={`font-display font-black text-2xl mt-1 ${outOfStockCount > 0 ? 'text-red-400' : 'text-slate-400'}`}>
            {outOfStockCount} <span className="text-xs font-normal text-slate-400">esgotados</span>
          </div>
          <button
            onClick={() => setFilterMode(outOfStockCount > 0 ? 'out_of_stock' : 'all')}
            className="text-[11px] text-red-300 underline mt-1 hover:text-red-200"
          >
            {outOfStockCount > 0 ? 'Ver produtos esgotados' : 'Nenhum esgotado'}
          </button>
        </div>

        {/* Low Stock Warning */}
        <div className={`border rounded-2xl p-4 shadow-md transition ${
          lowStockCount > 0 
            ? 'bg-amber-950/30 border-amber-500/50' 
            : 'bg-slate-900 border-slate-800'
        }`}>
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase">
            <span>Stock Baixo</span>
            <AlertTriangle className={`w-4 h-4 ${lowStockCount > 0 ? 'text-amber-400' : 'text-slate-500'}`} />
          </div>
          <div className={`font-display font-black text-2xl mt-1 ${lowStockCount > 0 ? 'text-amber-400' : 'text-slate-400'}`}>
            {lowStockCount} <span className="text-xs font-normal text-slate-400">em alerta</span>
          </div>
          <button
            onClick={() => setFilterMode(lowStockCount > 0 ? 'low_stock' : 'all')}
            className="text-[11px] text-amber-300 underline mt-1 hover:text-amber-200"
          >
            {lowStockCount > 0 ? 'Ver bebidas em alerta' : 'Stock seguro'}
          </button>
        </div>
      </div>

      {/* Header Actions: Search, Filter Tabs, Add Product Button */}
      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
        <div className="flex items-center gap-2 flex-1">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar bebida no stock..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="flex gap-1 bg-slate-900 border border-slate-800 p-1 rounded-xl">
            <button
              onClick={() => setFilterMode('all')}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition ${
                filterMode === 'all' ? 'bg-slate-800 text-white font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Todos ({products.length})
            </button>
            <button
              onClick={() => setFilterMode('out_of_stock')}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition ${
                filterMode === 'out_of_stock' ? 'bg-red-600 text-white font-bold' : 'text-slate-400 hover:text-red-300'
              }`}
            >
              Esgotados ({outOfStockCount})
            </button>
            <button
              onClick={() => setFilterMode('low_stock')}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition ${
                filterMode === 'low_stock' ? 'bg-amber-600 text-white font-bold' : 'text-slate-400 hover:text-amber-300'
              }`}
            >
              Baixo ({lowStockCount})
            </button>
            <button
              onClick={() => setFilterMode('top_sellers')}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition ${
                filterMode === 'top_sellers' ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-blue-300'
              }`}
            >
              Mais Vendidos
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {products.length > 0 && onClearAllRecords && (
            <button
              type="button"
              id="clear-all-records-btn"
              onClick={() => {
                if (confirm('Atenção: Tem certeza de que deseja apagar TODOS os registos (bebidas, vendas, despesas) e começar o bar do zero?')) {
                  onClearAllRecords();
                }
              }}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-rose-950/40 text-slate-400 hover:text-rose-300 border border-slate-700/80 hover:border-rose-900/60 font-semibold text-xs flex items-center gap-1.5 transition"
              title="Apagar todos os registos para começar do zero"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Limpar Tudo</span>
            </button>
          )}

          <button
            type="button"
            id="open-add-product-btn"
            onClick={() => setIsAddModalOpen(true)}
            className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-display font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-amber-950/40 transition active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Registar Nova Bebida</span>
          </button>
        </div>
      </div>

      {/* Stock Table List */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-lg">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-800/80 uppercase tracking-wider text-[11px] text-slate-400 font-semibold border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Bebida / Volume</th>
                <th className="py-3 px-3">Categoria</th>
                <th className="py-3 px-3 text-right">P. Custo</th>
                <th className="py-3 px-3 text-right">P. Venda</th>
                <th className="py-3 px-3 text-right">Lucro/Un.</th>
                <th className="py-3 px-3 text-center">Stock Atual</th>
                <th className="py-3 px-3 text-center">Saídas</th>
                <th className="py-3 px-4 text-center">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {displayedProducts.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-14 px-4 text-center">
                    <div className="max-w-md mx-auto space-y-3">
                      <div className="w-12 h-12 mx-auto rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                        <Package className="w-6 h-6" />
                      </div>
                      <h4 className="font-display font-bold text-base text-slate-200">
                        {products.length === 0 ? 'Nenhuma bebida registada no stock' : 'Nenhuma bebida encontrada'}
                      </h4>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        {products.length === 0
                          ? 'O seu inventário está vazio e sem registos de exemplo. Cadastre aqui as suas garrafas, latas e doses com preço de custo, venda e stock inicial.'
                          : 'Nenhuma bebida corresponde aos critérios de busca ou filtro selecionado.'}
                      </p>
                      {products.length === 0 && (
                        <button
                          type="button"
                          id="empty-stock-add-btn"
                          onClick={() => setIsAddModalOpen(true)}
                          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-display font-bold text-xs shadow-lg shadow-amber-950/40 transition active:scale-95"
                        >
                          <Plus className="w-4 h-4" />
                          <span>Registar Primeira Bebida</span>
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ) : (
                displayedProducts.map((product) => {
                  const isOut = product.currentStock <= 0;
                  const isLow = product.currentStock > 0 && product.currentStock <= product.minStockAlert;
                  const unitProfit = product.sellPrice - product.costPrice;
                  const margin = product.sellPrice > 0 ? Math.round((unitProfit / product.sellPrice) * 100) : 0;

                  return (
                    <tr
                      key={product.id}
                      id={`stock-row-${product.id}`}
                      className={`hover:bg-slate-800/40 transition ${
                        isOut ? 'bg-red-950/10' : isLow ? 'bg-amber-950/10' : ''
                      }`}
                    >
                    {/* Name & volume */}
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-100 text-sm">{product.name}</div>
                      <div className="text-[11px] text-slate-400">{product.volume || 'Bebida'}</div>
                    </td>

                    {/* Category */}
                    <td className="py-3 px-3">
                      <span className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 text-[11px]">
                        {product.category}
                      </span>
                    </td>

                    {/* Cost */}
                    <td className="py-3 px-3 text-right font-mono text-slate-400">
                      {product.costPrice} {currency}
                    </td>

                    {/* Sell Price */}
                    <td className="py-3 px-3 text-right font-mono font-bold text-amber-400 text-sm">
                      {product.sellPrice} {currency}
                    </td>

                    {/* Unit Profit */}
                    <td className="py-3 px-3 text-right font-mono text-emerald-400">
                      +{unitProfit} {currency}
                      <span className="text-[10px] text-slate-400 block">({margin}%)</span>
                    </td>

                    {/* Current Stock with Alert Badges */}
                    <td className="py-3 px-3 text-center">
                      {isOut ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-red-600 text-white font-bold text-[11px] animate-pulse">
                          <AlertTriangle className="w-3 h-3" />
                          0 (Esgotado)
                        </span>
                      ) : isLow ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold text-[11px]">
                          <AlertTriangle className="w-3 h-3" />
                          {product.currentStock} un. (Baixo)
                        </span>
                      ) : (
                        <span className="font-bold text-emerald-400 text-sm">
                          {product.currentStock} un.
                        </span>
                      )}
                      <span className="text-[10px] text-slate-400 block">mín: {product.minStockAlert}</span>
                    </td>

                    {/* Total Exits */}
                    <td className="py-3 px-3 text-center">
                      <span className="font-display font-extrabold text-blue-400 text-sm">
                        {product.totalSold}
                      </span>
                    </td>

                    {/* Actions: Restock, Edit, Delete */}
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            setRestockProduct(product);
                            setRestockQty(24);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 font-bold text-xs flex items-center gap-1 transition"
                          title="Repor Stock"
                        >
                          <PlusCircle className="w-3.5 h-3.5" />
                          <span>Repor</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setEditingProduct({ ...product })}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                          title="Editar Bebida e Preços"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            if (confirm(`Tem certeza que deseja apagar "${product.name}" do sistema?`)) {
                              onDeleteProduct(product.id);
                            }
                          }}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-900/60 text-slate-400 hover:text-rose-300 transition"
                          title="Excluir"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              }))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: Registar Nova Bebida */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <h3 className="font-display font-bold text-lg text-slate-100 flex items-center gap-2">
                <PlusCircle className="w-5 h-5 text-amber-400" />
                Registar Nova Bebida no Bar
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateProduct} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Nome da Bebida *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Laurentina Preta, 2M, Heineken, Jameson..."
                  value={newProdName}
                  onChange={(e) => setNewProdName(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:border-amber-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Categoria
                  </label>
                  <select
                    value={newProdCategory}
                    onChange={(e) => setNewProdCategory(e.target.value as ProductCategory)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:border-amber-500 outline-none"
                  >
                    {CATEGORIES.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Tamanho / Volume
                  </label>
                  <input
                    type="text"
                    placeholder="Ex: 330ml, 550ml, Dose..."
                    value={newProdVolume}
                    onChange={(e) => setNewProdVolume(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:border-amber-500 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Preço de Custo (Compra) ({currency})
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={newProdCost}
                    onChange={(e) => setNewProdCost(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:border-amber-500 outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-amber-400 mb-1">
                    Preço de Venda Padrão ({currency}) *
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="any"
                    required
                    value={newProdSell}
                    onChange={(e) => setNewProdSell(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-800 border-2 border-amber-500/80 rounded-xl px-3 py-2 text-sm text-amber-300 font-bold focus:border-amber-400 outline-none font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Stock Inicial (Unidades)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={newProdStock}
                    onChange={(e) => setNewProdStock(parseInt(e.target.value) || 0)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:border-amber-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Alerta de Fim de Stock (Mínimo)
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={newProdMinAlert}
                    onChange={(e) => setNewProdMinAlert(parseInt(e.target.value) || 5)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:border-amber-500 outline-none"
                  />
                </div>
              </div>

              {/* Profit Preview */}
              <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 text-xs flex items-center justify-between text-slate-300">
                <span>Lucro por unidade vendida:</span>
                <span className="font-bold text-emerald-400 font-mono">
                  +{(newProdSell - newProdCost).toLocaleString('pt-PT')} {currency} (
                  {newProdSell > 0 ? Math.round(((newProdSell - newProdCost) / newProdSell) * 100) : 0}%)
                </span>
              </div>

              <div className="flex gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-medium text-xs hover:bg-slate-700"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-display font-bold text-xs shadow-md shadow-amber-950/50 flex items-center justify-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>Guardar Bebida</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Editar Bebida */}
      {editingProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <h3 className="font-display font-bold text-lg text-slate-100 flex items-center gap-2">
                <Edit3 className="w-5 h-5 text-amber-400" />
                Editar Bebida & Preços
              </h3>
              <button
                onClick={() => setEditingProduct(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUpdateProductSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Nome da Bebida
                </label>
                <input
                  type="text"
                  required
                  value={editingProduct.name}
                  onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:border-amber-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Categoria
                  </label>
                  <select
                    value={editingProduct.category}
                    onChange={(e) => setEditingProduct({ ...editingProduct, category: e.target.value as ProductCategory })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:border-amber-500 outline-none"
                  >
                    {CATEGORIES.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Volume
                  </label>
                  <input
                    type="text"
                    value={editingProduct.volume || ''}
                    onChange={(e) => setEditingProduct({ ...editingProduct, volume: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:border-amber-500 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Preço de Custo ({currency})
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={editingProduct.costPrice}
                    onChange={(e) => setEditingProduct({ ...editingProduct, costPrice: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:border-amber-500 outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-amber-400 mb-1">
                    Preço de Venda ({currency})
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="any"
                    required
                    value={editingProduct.sellPrice}
                    onChange={(e) => setEditingProduct({ ...editingProduct, sellPrice: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-slate-800 border-2 border-amber-500/80 rounded-xl px-3 py-2 text-sm text-amber-300 font-bold focus:border-amber-400 outline-none font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Stock Atual (Ajuste direto)
                  </label>
                  <input
                    type="number"
                    value={editingProduct.currentStock}
                    onChange={(e) => setEditingProduct({ ...editingProduct, currentStock: parseInt(e.target.value) || 0 })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:border-amber-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Alerta de Fim de Stock (Mínimo)
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={editingProduct.minStockAlert}
                    onChange={(e) => setEditingProduct({ ...editingProduct, minStockAlert: parseInt(e.target.value) || 5 })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:border-amber-500 outline-none"
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setEditingProduct(null)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-medium text-xs hover:bg-slate-700"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-display font-bold text-xs shadow-md shadow-amber-950/50 flex items-center justify-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>Salvar Alterações</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Reposição de Stock Rápida */}
      {restockProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <h3 className="font-display font-bold text-lg text-slate-100 flex items-center gap-2">
                <PlusCircle className="w-5 h-5 text-emerald-400" />
                Reposição de Stock: {restockProduct.name}
              </h3>
              <button
                onClick={() => setRestockProduct(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <p className="text-xs text-slate-400">
                Stock atual: <span className="font-bold text-white">{restockProduct.currentStock} un.</span>
              </p>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">
                  Quantidade a Adicionar ao Stock
                </label>
                <input
                  type="number"
                  min="1"
                  value={restockQty}
                  onChange={(e) => setRestockQty(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-full bg-slate-800 border-2 border-emerald-500/70 rounded-xl px-4 py-3 text-2xl font-display font-black text-emerald-400 text-center outline-none"
                />
              </div>

              {/* Quick Grade / Box shortcuts */}
              <div className="grid grid-cols-4 gap-2">
                {[6, 12, 24, 48].map((q) => (
                  <button
                    key={q}
                    type="button"
                    onClick={() => setRestockQty(q)}
                    className={`py-2 rounded-xl text-xs font-bold border transition ${
                      restockQty === q
                        ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                        : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    +{q} {q === 24 ? '(Grade)' : q === 12 ? '(Caixa)' : 'un'}
                  </button>
                ))}
              </div>

              <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 text-xs text-slate-300">
                Stock final após reposição:{' '}
                <span className="font-bold text-emerald-400 font-display text-sm">
                  {restockProduct.currentStock + restockQty} unidades
                </span>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setRestockProduct(null)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-medium text-xs hover:bg-slate-700"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleExecuteRestock}
                  className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-display font-bold text-xs shadow-md shadow-emerald-950/50 flex items-center justify-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>Confirmar Reposição (+{restockQty} un)</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
