import React, { useState, useMemo } from 'react';
import { Product, Sale, ProductCategory, PaymentMethod } from '../types';
import { PriceConfirmModal } from './PriceConfirmModal';
import { soundFX } from '../services/audio';
import { PAYMENT_CONFIGS, getPaymentMethodShortLabel, normalizePaymentMethod } from '../utils/payment';
import { 
  Search, 
  Zap, 
  AlertTriangle, 
  CheckCircle, 
  TrendingUp, 
  ShoppingBag, 
  RotateCcw, 
  Sparkles,
  Flame,
  Plus,
  Package,
  PlusCircle,
  Banknote,
  Smartphone
} from 'lucide-react';

interface PosViewProps {
  products: Product[];
  salesToday: Sale[];
  currency: string;
  fastSaleMode: boolean;
  onToggleFastSaleMode: () => void;
  onRegisterSale: (
    product: Product,
    quantity: number,
    unitPrice: number,
    paymentMethod: PaymentMethod,
    customerName?: string,
    notes?: string,
    customerPhone?: string,
    dueDate?: string
  ) => void;
  onReverseSale: (saleId: string) => void;
  onOpenRestockModal: (product?: Product) => void;
  onNavigateToDebts?: () => void;
}

const CATEGORIES: ('Todas' | ProductCategory)[] = [
  'Todas',
  'Cerveja',
  'Refrigerante',
  'Cider',
  'Destilado',
  'Vinho',
  'Energético',
  'Água',
  'Petisco',
  'Outros',
];

export const PosView: React.FC<PosViewProps> = ({
  products,
  salesToday,
  currency,
  fastSaleMode,
  onToggleFastSaleMode,
  onRegisterSale,
  onReverseSale,
  onOpenRestockModal,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'Todas' | ProductCategory>('Todas');
  const [activeModalProduct, setActiveModalProduct] = useState<Product | null>(null);
  const [lastSoldProduct, setLastSoldProduct] = useState<string | null>(null);
  const [fastPaymentMethod, setFastPaymentMethod] = useState<PaymentMethod>('fisico');

  // Customer suggestions for fiado
  const existingCustomers = useMemo(() => {
    const set = new Set<string>();
    salesToday.forEach((s) => {
      if (s.customerName && s.customerName.trim()) {
        set.add(s.customerName.trim());
      }
    });
    return Array.from(set);
  }, [salesToday]);

  // Filtered products list
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchesCategory = selectedCategory === 'Todas' || p.category === selectedCategory;
      const matchesSearch =
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (p.volume && p.volume.toLowerCase().includes(searchQuery.toLowerCase())) ||
        p.category.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [products, selectedCategory, searchQuery]);

  // Out of stock and low stock alerts count
  const outOfStockItems = useMemo(() => products.filter((p) => p.currentStock <= 0), [products]);
  const lowStockItems = useMemo(
    () => products.filter((p) => p.currentStock > 0 && p.currentStock <= p.minStockAlert),
    [products]
  );

  // Quick metrics today
  const totalRevenueToday = useMemo(
    () => salesToday.filter((s) => !s.isReversed).reduce((sum, s) => sum + s.totalAmount, 0),
    [salesToday]
  );
  const totalDrinksSoldToday = useMemo(
    () =>
      salesToday
        .filter((s) => !s.isReversed)
        .reduce((sum, s) => sum + s.items.reduce((iSum, item) => iSum + item.quantity, 0), 0),
    [salesToday]
  );

  // Handle clicking on product card
  const handleProductClick = (product: Product) => {
    if (fastSaleMode) {
      // 1-Touch Fast Sale
      soundFX.playSaleChime();
      onRegisterSale(product, 1, product.sellPrice, fastPaymentMethod);
      setLastSoldProduct(product.name);
      setTimeout(() => setLastSoldProduct(null), 2500);
    } else {
      // Open modal to confirm or dictate price
      soundFX.playClick();
      setActiveModalProduct(product);
    }
  };

  return (
    <div className="space-y-4">
      {/* Top Banner: Real-time quick shift stats & Fast Mode toggle */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4 shadow-lg backdrop-blur">
        <div className="flex items-center gap-6">
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
              Vendido Hoje
            </div>
            <div className="font-display font-black text-2xl text-emerald-400">
              {totalRevenueToday.toLocaleString('pt-PT')} <span className="text-sm font-semibold text-emerald-300">{currency}</span>
            </div>
          </div>

          <div className="h-8 w-px bg-slate-800 hidden sm:block" />

          <div>
            <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
              Bebidas Servidas
            </div>
            <div className="font-display font-extrabold text-2xl text-amber-400 flex items-center gap-1.5">
              <span>{totalDrinksSoldToday}</span>
              <span className="text-xs text-slate-400 font-normal">unidades</span>
            </div>
          </div>
        </div>

        {/* Fast Mode Controls */}
        <div className="flex flex-wrap items-center gap-2.5 ml-auto">
          {fastSaleMode && (
            <div className="flex items-center gap-1.5 bg-slate-950/80 border border-slate-700/80 rounded-xl p-1 text-xs">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 px-2">
                Receber por:
              </span>
              <button
                type="button"
                id="fast-pay-fisico-btn"
                onClick={() => {
                  soundFX.playClick();
                  setFastPaymentMethod('fisico');
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1 transition ${
                  fastPaymentMethod === 'fisico'
                    ? 'bg-emerald-500 text-slate-950 shadow'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Banknote className="w-3.5 h-3.5" />
                <span>Físico</span>
              </button>
              <button
                type="button"
                id="fast-pay-emola-btn"
                onClick={() => {
                  soundFX.playClick();
                  setFastPaymentMethod('emola');
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1 transition ${
                  fastPaymentMethod === 'emola'
                    ? 'bg-orange-500 text-white shadow'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>e-Mola</span>
              </button>
              <button
                type="button"
                id="fast-pay-mpesa-btn"
                onClick={() => {
                  soundFX.playClick();
                  setFastPaymentMethod('mpesa');
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1 transition ${
                  fastPaymentMethod === 'mpesa'
                    ? 'bg-red-600 text-white shadow'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>M-Pesa</span>
              </button>
              <button
                type="button"
                id="fast-pay-mkash-btn"
                onClick={() => {
                  soundFX.playClick();
                  setFastPaymentMethod('mkash');
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1 transition ${
                  fastPaymentMethod === 'mkash'
                    ? 'bg-amber-400 text-slate-950 shadow'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>M-Kash</span>
              </button>
            </div>
          )}

          <button
            type="button"
            id="toggle-fast-sale-btn"
            onClick={onToggleFastSaleMode}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl border text-xs font-bold transition ${
              fastSaleMode
                ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-md shadow-amber-950/40'
                : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Zap className={`w-4 h-4 ${fastSaleMode ? 'text-amber-400 fill-amber-400' : 'text-slate-400'}`} />
            <span>{fastSaleMode ? '1-Toque ATIVO' : 'Confirmar Preço ao Vender'}</span>
          </button>
        </div>
      </div>

      {/* Stock Alerts Notice if any drinks are critical or out of stock */}
      {(outOfStockItems.length > 0 || lowStockItems.length > 0) && (
        <div className="bg-gradient-to-r from-red-950/40 via-amber-950/30 to-slate-900 border border-amber-500/40 rounded-2xl p-3.5 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5">
            <span className="p-2 rounded-xl bg-amber-500/20 text-amber-400 shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </span>
            <div>
              <span className="font-bold text-amber-300">Atenção ao Balcão: </span>
              {outOfStockItems.length > 0 && (
                <span className="text-red-300 font-semibold mr-2">
                  {outOfStockItems.length} produto(s) ESGOTADO(S) ({outOfStockItems.map((p) => p.name).slice(0, 3).join(', ')}
                  {outOfStockItems.length > 3 ? '...' : ''})
                </span>
              )}
              {lowStockItems.length > 0 && (
                <span className="text-amber-200">
                  {lowStockItems.length} com stock baixo
                </span>
              )}
            </div>
          </div>
          <button
            type="button"
            onClick={() => onOpenRestockModal()}
            className="shrink-0 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Repor Stock</span>
          </button>
        </div>
      )}

      {/* Instant Sold Toast Notification */}
      {lastSoldProduct && (
        <div className="bg-emerald-500/90 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-lg flex items-center justify-center gap-2 animate-bounce">
          <CheckCircle className="w-4 h-4 text-white" />
          <span>Venda registada com sucesso: {lastSoldProduct}!</span>
        </div>
      )}

      {/* Search & Category Filter Pills */}
      <div className="space-y-3">
        {/* Search input */}
        <div className="relative">
          <Search className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            id="pos-search-input"
            type="text"
            placeholder="Buscar cerveja, refri, whisky pelo nome..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-900 border border-slate-700/80 rounded-xl pl-11 pr-4 py-3 text-slate-100 placeholder-slate-400 text-sm focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white px-2 py-1"
            >
              Limpar
            </button>
          )}
        </div>

        {/* Categories Pills */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => {
                soundFX.playClick();
                setSelectedCategory(cat);
              }}
              className={`shrink-0 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition ${
                selectedCategory === cat
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-950/50'
                  : 'bg-slate-900/80 border border-slate-800 text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Product Grid - Designed for Rapid Finger Taps at the Bar Counter */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
        {filteredProducts.map((product) => {
          const isOut = product.currentStock <= 0;
          const isLow = product.currentStock > 0 && product.currentStock <= product.minStockAlert;

          return (
            <div
              key={product.id}
              id={`product-card-${product.id}`}
              className={`relative bg-slate-900/90 border rounded-2xl p-3.5 flex flex-col justify-between transition-all duration-150 select-none shadow-md ${
                isOut
                  ? 'border-red-900/60 opacity-80'
                  : isLow
                  ? 'border-amber-500/50 hover:border-amber-400'
                  : 'border-slate-800 hover:border-slate-700'
              }`}
            >
              {/* Category tag & stock pill */}
              <div className="flex items-start justify-between gap-1 mb-2">
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md bg-slate-800 text-slate-400">
                  {product.category}
                </span>

                {/* Stock status indicator */}
                {isOut ? (
                  <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-red-600 text-white animate-pulse">
                    Fim Stock
                  </span>
                ) : isLow ? (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40">
                    Resta {product.currentStock}
                  </span>
                ) : (
                  <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-slate-800 text-emerald-400">
                    {product.currentStock} un.
                  </span>
                )}
              </div>

              {/* Product Info */}
              <div className="my-1">
                <h4 className="font-display font-bold text-base text-slate-100 leading-snug line-clamp-2">
                  {product.name}
                </h4>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  {product.volume || 'Bebida'}
                </p>
              </div>

              {/* Price & Action Button */}
              <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between gap-2">
                <div>
                  <span className="text-[10px] uppercase text-slate-400 block font-medium">Preço</span>
                  <span className="font-display font-extrabold text-lg text-amber-400">
                    {product.sellPrice} <span className="text-xs font-semibold text-amber-300">{currency}</span>
                  </span>
                </div>

                <button
                  type="button"
                  id={`sell-btn-${product.id}`}
                  onClick={() => handleProductClick(product)}
                  className={`px-3 py-2 rounded-xl font-display font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition shadow ${
                    isOut
                      ? 'bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-800'
                      : fastSaleMode
                      ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 font-black'
                      : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                  }`}
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  <span>Vender</span>
                </button>
              </div>

              {/* Exits footer */}
              <div className="mt-1 text-[10px] text-slate-400 flex items-center justify-between">
                <span>Saídas: {product.totalSold} un.</span>
                <span className="text-slate-400">Custo: {product.costPrice}{currency}</span>
              </div>
            </div>
          );
        })}
      </div>

      {products.length === 0 ? (
        <div className="bg-slate-900 border-2 border-dashed border-slate-800 rounded-3xl p-10 text-center text-slate-300 space-y-4 shadow-xl">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shadow-lg">
            <Package className="w-8 h-8" />
          </div>
          <div className="max-w-md mx-auto space-y-2">
            <h3 className="font-display font-bold text-xl text-white">Nenhuma bebida registada no balcão</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              O sistema está pronto e sem registos de exemplo. Cadastre as suas cervejas, refrigerantes, vinhos e destilados no Stock para começar a vender.
            </p>
          </div>
          <button
            type="button"
            id="empty-pos-add-drink-btn"
            onClick={() => onOpenRestockModal()}
            className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-display font-bold text-xs shadow-xl shadow-amber-950/40 transition active:scale-95"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Cadastrar Minhas Bebidas no Stock</span>
          </button>
        </div>
      ) : filteredProducts.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center text-slate-400">
          <p className="text-sm">Nenhuma bebida encontrada para "{searchQuery}".</p>
        </div>
      ) : null}

      {/* Recent sales ticker / Quick Undo bar */}
      {salesToday.length > 0 && (
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-3.5 mt-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
              Últimas Vendas Registadas no Balcão
            </span>
            <span className="text-xs text-slate-400">
              Total hoje: {salesToday.filter((s) => !s.isReversed).length} vendas
            </span>
          </div>

          <div className="space-y-1.5">
            {salesToday
              .filter((s) => !s.isReversed)
              .slice(0, 3)
              .map((sale) => {
                const item = sale.items[0];
                return (
                  <div
                    key={sale.id}
                    className="flex items-center justify-between py-1.5 px-3 bg-slate-950/60 border border-slate-800 rounded-xl text-xs"
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-slate-400 font-mono text-[11px]">{sale.timeStr}</span>
                      <span className="font-semibold text-slate-200">
                        {item?.quantity}x {item?.productName}
                      </span>
                      {(() => {
                        const norm = normalizePaymentMethod(sale.paymentMethod);
                        const cfg = PAYMENT_CONFIGS[norm];
                        return (
                          <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold border ${cfg?.badgeBg || 'bg-slate-800'} ${cfg?.badgeBorder || 'border-slate-700'} ${cfg?.badgeText || 'text-slate-300'}`}>
                            {cfg?.shortLabel || sale.paymentMethod}
                            {sale.customerName ? `: ${sale.customerName}` : ''}
                          </span>
                        );
                      })()}
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="font-display font-bold text-amber-400">
                        {sale.totalAmount} {currency}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          if (confirm(`Deseja estornar/cancelar esta venda de ${item?.productName}? O stock será devolvido.`)) {
                            onReverseSale(sale.id);
                          }
                        }}
                        className="p-1 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded transition"
                        title="Desfazer/Estornar venda"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* Active Modal */}
      {activeModalProduct && (
        <PriceConfirmModal
          product={activeModalProduct}
          currency={currency}
          existingCustomers={existingCustomers}
          onClose={() => setActiveModalProduct(null)}
          onConfirm={({ quantity, unitPrice, paymentMethod, customerName, notes, customerPhone, dueDate }) => {
            onRegisterSale(
              activeModalProduct,
              quantity,
              unitPrice,
              paymentMethod,
              customerName,
              notes,
              customerPhone,
              dueDate
            );
            setActiveModalProduct(null);
            setLastSoldProduct(activeModalProduct.name);
            setTimeout(() => setLastSoldProduct(null), 2500);
          }}
        />
      )}
    </div>
  );
};
