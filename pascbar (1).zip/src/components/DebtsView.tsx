import React, { useState, useMemo } from 'react';
import { Product, Sale, PaymentMethod } from '../types';
import { soundFX } from '../services/audio';
import { PAYMENT_CONFIGS, normalizePaymentMethod, getPaymentMethodShortLabel } from '../utils/payment';
import { 
  BookOpen, 
  Plus, 
  Search, 
  CheckCircle2, 
  Clock, 
  Phone, 
  MessageSquare, 
  AlertTriangle, 
  User, 
  Calendar, 
  DollarSign, 
  Check, 
  X, 
  ChevronDown, 
  ChevronUp,
  Banknote,
  Smartphone,
  CreditCard,
  Send,
  RotateCcw,
  Sparkles,
  Users
} from 'lucide-react';

interface DebtsViewProps {
  sales: Sale[];
  products: Product[];
  currency: string;
  barName: string;
  onRegisterSale: (
    product: Product,
    quantity: number,
    unitPrice: number,
    paymentMethod: PaymentMethod,
    customerName?: string,
    notes?: string,
    customerPhone?: string,
    dueDate?: string
  ) => void;
  onSettleDebt: (
    saleId: string,
    settlementMethod: PaymentMethod,
    notes?: string
  ) => void;
  onSettleAllCustomerDebts: (
    customerName: string,
    settlementMethod: PaymentMethod,
    notes?: string
  ) => void;
  onReverseSale: (saleId: string) => void;
}

export const DebtsView: React.FC<DebtsViewProps> = ({
  sales,
  products,
  currency,
  barName,
  onRegisterSale,
  onSettleDebt,
  onSettleAllCustomerDebts,
  onReverseSale,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'pending' | 'settled' | 'all'>('pending');
  const [viewMode, setViewMode] = useState<'grouped' | 'list'>('grouped');
  
  // Modals
  const [isNewDebtModalOpen, setIsNewDebtModalOpen] = useState(false);
  const [settleModalData, setSettleModalData] = useState<{
    customerName: string;
    saleId?: string; // undefined means all debts for this customer
    amount: number;
    itemsSummary: string;
  } | null>(null);
  
  // Expanded cards state in grouped view
  const [expandedCustomers, setExpandedCustomers] = useState<Record<string, boolean>>({});

  // 1. All fiado/debt sales (excluding reversed)
  const debtSales = useMemo(() => {
    return sales.filter(
      (s) => !s.isReversed && (s.paymentMethod === 'fiado' || s.isPaid !== undefined)
    );
  }, [sales]);

  // 2. Metrics
  const metrics = useMemo(() => {
    let pendingTotal = 0;
    let settledTotal = 0;
    const pendingCustomersSet = new Set<string>();
    const allCustomersSet = new Set<string>();

    debtSales.forEach((s) => {
      const custName = (s.customerName || 'Cliente sem nome').trim();
      allCustomersSet.add(custName);

      const isUnpaid = s.isPaid !== true;
      if (isUnpaid) {
        pendingTotal += s.totalAmount;
        pendingCustomersSet.add(custName);
      } else {
        settledTotal += s.totalAmount;
      }
    });

    return {
      pendingTotal,
      settledTotal,
      pendingCustomersCount: pendingCustomersSet.size,
      totalCustomersCount: allCustomersSet.size,
      pendingDebtsCount: debtSales.filter((s) => s.isPaid !== true).length,
    };
  }, [debtSales]);

  // 3. Known customers list for autocompletion
  const knownCustomers = useMemo(() => {
    const map = new Map<string, { name: string; phone?: string; totalDebts: number }>();
    sales.forEach((s) => {
      if (s.customerName && s.customerName.trim()) {
        const name = s.customerName.trim();
        const existing = map.get(name) || { name, phone: s.customerPhone, totalDebts: 0 };
        if (s.customerPhone && !existing.phone) {
          existing.phone = s.customerPhone;
        }
        if (s.paymentMethod === 'fiado' && s.isPaid !== true && !s.isReversed) {
          existing.totalDebts += s.totalAmount;
        }
        map.set(name, existing);
      }
    });
    return Array.from(map.values());
  }, [sales]);

  // 4. Filtered sales based on search & status
  const filteredSales = useMemo(() => {
    return debtSales.filter((s) => {
      const isUnpaid = s.isPaid !== true;
      if (statusFilter === 'pending' && !isUnpaid) return false;
      if (statusFilter === 'settled' && isUnpaid) return false;

      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase();
      const name = (s.customerName || '').toLowerCase();
      const phone = (s.customerPhone || '').toLowerCase();
      const itemMatch = s.items.some((i) => i.productName.toLowerCase().includes(q));
      const notesMatch = (s.notes || '').toLowerCase().includes(q);

      return name.includes(q) || phone.includes(q) || itemMatch || notesMatch;
    });
  }, [debtSales, statusFilter, searchQuery]);

  // 5. Grouped by customer
  const groupedByCustomer = useMemo(() => {
    const groups: Record<
      string,
      {
        customerName: string;
        customerPhone?: string;
        totalPending: number;
        totalSettled: number;
        sales: Sale[];
      }
    > = {};

    filteredSales.forEach((sale) => {
      const name = (sale.customerName || 'Cliente sem nome').trim();
      if (!groups[name]) {
        groups[name] = {
          customerName: name,
          customerPhone: sale.customerPhone,
          totalPending: 0,
          totalSettled: 0,
          sales: [],
        };
      }
      if (sale.customerPhone && !groups[name].customerPhone) {
        groups[name].customerPhone = sale.customerPhone;
      }

      if (sale.isPaid === true) {
        groups[name].totalSettled += sale.totalAmount;
      } else {
        groups[name].totalPending += sale.totalAmount;
      }
      groups[name].sales.push(sale);
    });

    // Sort: highest pending debt first
    return Object.values(groups).sort((a, b) => b.totalPending - a.totalPending);
  }, [filteredSales]);

  // Toggle customer card collapse
  const toggleCustomer = (customerName: string) => {
    setExpandedCustomers((prev) => ({
      ...prev,
      [customerName]: !prev[customerName],
    }));
  };

  // Generate WhatsApp reminder message
  const handleSendWhatsAppReminder = (customerName: string, phone: string | undefined, totalDue: number, customerSales: Sale[]) => {
    const unpaidItems = customerSales
      .filter((s) => s.isPaid !== true)
      .map((s) => {
        const itemNames = s.items.map((i) => `${i.quantity}x ${i.productName}`).join(', ');
        return `• ${s.dateStr}: ${itemNames} (${s.totalAmount} ${currency})`;
      })
      .join('\n');

    const msg = `Olá *${customerName}*! 👋\nPassando para lembrar da conta pendente no *${barName}* no valor total de *${totalDue.toLocaleString('pt-PT')} ${currency}*.\n\n*Detalhes do consumo:*\n${unpaidItems}\n\nPodes passar no balcão ou pagar por carteira móvel:\n🟠 *e-Mola* / 🔴 *M-Pesa* / 🟡 *M-Kash*\n\nMuito obrigado pela preferência! 🙏`;

    if (phone && phone.replace(/\D/g, '').length >= 8) {
      const cleanPhone = phone.replace(/\D/g, '');
      // If no international prefix, add Mozambique +258
      const fullPhone = cleanPhone.startsWith('258') ? cleanPhone : `258${cleanPhone}`;
      const url = `https://wa.me/${fullPhone}?text=${encodeURIComponent(msg)}`;
      window.open(url, '_blank');
    } else {
      // Copy to clipboard
      navigator.clipboard.writeText(msg);
      alert('Mensagem copiada para a área de transferência! Pode colar no WhatsApp do cliente.');
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Top Banner & Action */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30 flex items-center justify-center">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-display font-black text-xl text-white tracking-tight">
                  Caderneta de Fiados & Contas a Receber
                </h2>
                {metrics.pendingDebtsCount > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-xs font-bold border border-purple-500/40">
                    {metrics.pendingDebtsCount} {metrics.pendingDebtsCount === 1 ? 'dívida ativa' : 'dívidas ativas'}
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400">
                Registo e controlo rigoroso de bebidas consumidas e não pagas junto dos nomes dos clientes
              </p>
            </div>
          </div>
        </div>

        <button
          type="button"
          id="btn-open-new-debt"
          onClick={() => {
            soundFX.playClick();
            setIsNewDebtModalOpen(true);
          }}
          className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-500 hover:to-purple-600 text-white font-display font-bold text-sm shadow-md shadow-purple-950/50 transition active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>Registar Nova Dívida / Fiado</span>
        </button>
      </div>

      {/* KPI Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Total a Receber */}
        <div className="bg-slate-900/90 border border-purple-500/40 rounded-2xl p-4 shadow-md space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
            <span>Total a Receber</span>
            <Clock className="w-4 h-4 text-purple-400" />
          </div>
          <div className="font-display font-black text-2xl text-purple-300 tracking-tight">
            {metrics.pendingTotal.toLocaleString('pt-PT')} <span className="text-sm font-normal text-purple-400">{currency}</span>
          </div>
          <div className="text-[11px] text-slate-400 flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-purple-400 animate-ping inline-block" />
            Contas pendentes de pagamento
          </div>
        </div>

        {/* Clientes com Dívidas */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
            <span>Clientes Devedores</span>
            <Users className="w-4 h-4 text-amber-400" />
          </div>
          <div className="font-display font-black text-2xl text-amber-400 tracking-tight">
            {metrics.pendingCustomersCount}
          </div>
          <div className="text-[11px] text-slate-400">
            De um total de {metrics.totalCustomersCount} clientes cadastrados
          </div>
        </div>

        {/* Total Já Recuperado / Pago */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
            <span>Total Liquidado (Pago)</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="font-display font-black text-2xl text-emerald-400 tracking-tight">
            {metrics.settledTotal.toLocaleString('pt-PT')} <span className="text-sm font-normal text-emerald-500">{currency}</span>
          </div>
          <div className="text-[11px] text-slate-400">
            Dívidas recuperadas com sucesso
          </div>
        </div>

        {/* Média por Devedor */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
            <span>Média por Devedor</span>
            <DollarSign className="w-4 h-4 text-blue-400" />
          </div>
          <div className="font-display font-black text-2xl text-blue-400 tracking-tight">
            {metrics.pendingCustomersCount > 0
              ? Math.round(metrics.pendingTotal / metrics.pendingCustomersCount).toLocaleString('pt-PT')
              : 0}{' '}
            <span className="text-sm font-normal text-blue-500">{currency}</span>
          </div>
          <div className="text-[11px] text-slate-400">
            Valor médio pendente por cliente
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 sm:p-4 shadow-md flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Pesquisar por nome do cliente, telefone ou bebida..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950/80 border border-slate-700/80 rounded-xl pl-9 pr-3 py-2 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-purple-500"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
            >
              Limpar
            </button>
          )}
        </div>

        {/* Status Filters */}
        <div className="flex items-center gap-1 bg-slate-950/80 p-1 rounded-xl border border-slate-800 shrink-0">
          <button
            type="button"
            onClick={() => {
              soundFX.playClick();
              setStatusFilter('pending');
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              statusFilter === 'pending'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Pendentes ({metrics.pendingDebtsCount})
          </button>
          <button
            type="button"
            onClick={() => {
              soundFX.playClick();
              setStatusFilter('settled');
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              statusFilter === 'settled'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Liquidadas (Pagas)
          </button>
          <button
            type="button"
            onClick={() => {
              soundFX.playClick();
              setStatusFilter('all');
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              statusFilter === 'all'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Todas ({debtSales.length})
          </button>
        </div>

        {/* View Mode Toggle */}
        <div className="flex items-center gap-1 bg-slate-950/80 p-1 rounded-xl border border-slate-800 shrink-0">
          <button
            type="button"
            onClick={() => setViewMode('grouped')}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition ${
              viewMode === 'grouped' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-white'
            }`}
            title="Agrupar por Cliente"
          >
            Por Cliente
          </button>
          <button
            type="button"
            onClick={() => setViewMode('list')}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition ${
              viewMode === 'list' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-white'
            }`}
            title="Ver Todas as Vendas em Linhas"
          >
            Lista Detalhada
          </button>
        </div>
      </div>

      {/* Content Area */}
      {filteredSales.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center space-y-3">
          <div className="w-12 h-12 rounded-full bg-purple-500/20 text-purple-400 mx-auto flex items-center justify-center">
            <BookOpen className="w-6 h-6" />
          </div>
          <h3 className="font-display font-bold text-base text-slate-200">
            Nenhuma dívida encontrada
          </h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            {searchQuery
              ? `Não foram encontrados resultados para "${searchQuery}".`
              : statusFilter === 'pending'
              ? 'Excelente! Não há contas não pagas registadas no momento. Todos os clientes estão em dia.'
              : 'Nenhum registo de fiado encontrado com este filtro.'}
          </p>
          <button
            type="button"
            onClick={() => setIsNewDebtModalOpen(true)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition shadow-md"
          >
            <Plus className="w-4 h-4" />
            <span>Registar Conta Não Paga Agora</span>
          </button>
        </div>
      ) : viewMode === 'grouped' ? (
        /* 1. Grouped by Customer Cards */
        <div className="space-y-4">
          {groupedByCustomer.map((group) => {
            const isExpanded = expandedCustomers[group.customerName] !== false; // Default expanded
            const unpaidCount = group.sales.filter((s) => s.isPaid !== true).length;
            const hasPending = group.totalPending > 0;

            return (
              <div
                key={group.customerName}
                className={`bg-slate-900 border rounded-2xl overflow-hidden transition shadow-md ${
                  hasPending ? 'border-purple-500/50' : 'border-slate-800'
                }`}
              >
                {/* Customer Card Header */}
                <div className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900">
                  <div className="flex items-start sm:items-center gap-3">
                    <div
                      className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 font-display font-black text-lg ${
                        hasPending
                          ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                          : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      }`}
                    >
                      {group.customerName.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-display font-black text-base text-white">
                          {group.customerName}
                        </h3>
                        {hasPending ? (
                          <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30 text-[11px] font-bold">
                            {unpaidCount} {unpaidCount === 1 ? 'conta aberta' : 'contas abertas'}
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[11px] font-bold">
                            Tudo Pago ✔
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-3 text-xs text-slate-400 mt-0.5">
                        {group.customerPhone ? (
                          <span className="flex items-center gap-1 text-slate-300">
                            <Phone className="w-3 h-3 text-purple-400" />
                            {group.customerPhone}
                          </span>
                        ) : (
                          <span className="text-slate-500 italic">Sem telefone</span>
                        )}
                        <span>•</span>
                        <span>{group.sales.length} consumos registados</span>
                      </div>
                    </div>
                  </div>

                  {/* Right Side: Total and Actions */}
                  <div className="flex items-center justify-between sm:justify-end gap-3 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800">
                    <div className="text-left sm:text-right">
                      <div className="text-[11px] text-slate-400">Total a Pagar</div>
                      <div className={`font-display font-black text-lg sm:text-xl ${hasPending ? 'text-purple-300' : 'text-emerald-400'}`}>
                        {group.totalPending.toLocaleString('pt-PT')} {currency}
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {/* WhatsApp / Cobrar button */}
                      {hasPending && (
                        <button
                          type="button"
                          onClick={() => handleSendWhatsAppReminder(group.customerName, group.customerPhone, group.totalPending, group.sales)}
                          className="p-2 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 transition text-xs font-bold flex items-center gap-1"
                          title="Enviar lembrete de cobrança no WhatsApp"
                        >
                          <Send className="w-3.5 h-3.5" />
                          <span className="hidden md:inline">Cobrar</span>
                        </button>
                      )}

                      {/* Pay / Settle all */}
                      {hasPending && (
                        <button
                          type="button"
                          onClick={() => {
                            soundFX.playClick();
                            setSettleModalData({
                              customerName: group.customerName,
                              amount: group.totalPending,
                              itemsSummary: `${unpaidCount} contas pendentes no total`,
                            });
                          }}
                          className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-display font-bold text-xs shadow-md transition active:scale-95 flex items-center gap-1.5"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Liquidar Tudo</span>
                        </button>
                      )}

                      {/* Expand / Collapse */}
                      <button
                        type="button"
                        onClick={() => toggleCustomer(group.customerName)}
                        className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                        title={isExpanded ? 'Recolher detalhes' : 'Ver consumos'}
                      >
                        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Expanded Consumption List */}
                {isExpanded && (
                  <div className="border-t border-slate-800 bg-slate-950/50 p-3 sm:p-4 space-y-2">
                    <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-1">
                      Histórico de Contas e Bebidas deste Cliente
                    </div>

                    <div className="space-y-2">
                      {group.sales.map((sale) => {
                        const isUnpaid = sale.isPaid !== true;
                        const item = sale.items[0];

                        return (
                          <div
                            key={sale.id}
                            className={`p-3 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs transition ${
                              isUnpaid
                                ? 'bg-slate-900/90 border-purple-500/30'
                                : 'bg-slate-900/40 border-slate-800 opacity-70'
                            }`}
                          >
                            {/* Left info */}
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="font-semibold text-slate-200">
                                  {sale.items.map((i) => `${i.quantity}x ${i.productName}`).join(' + ')}
                                </span>
                                {isUnpaid ? (
                                  <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                                    Não Pago
                                  </span>
                                ) : (
                                  <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                                    Liquidado em {sale.paidDateStr || 'caixa'}
                                    {sale.settlementMethod && ` (${PAYMENT_CONFIGS[normalizePaymentMethod(sale.settlementMethod)]?.shortLabel || sale.settlementMethod})`}
                                  </span>
                                )}
                              </div>

                              <div className="flex flex-wrap items-center gap-3 text-slate-400 text-[11px]">
                                <span>📅 {sale.dateStr} às {sale.timeStr}</span>
                                {sale.dueDate && (
                                  <span className="text-amber-400 font-medium">
                                    ⏳ Previsão: {sale.dueDate}
                                  </span>
                                )}
                                {sale.notes && (
                                  <span className="italic text-slate-400">"{sale.notes}"</span>
                                )}
                              </div>
                            </div>

                            {/* Right info & actions */}
                            <div className="flex items-center justify-between sm:justify-end gap-3 pt-1 sm:pt-0">
                              <div className="font-display font-bold text-sm text-purple-300">
                                {sale.totalAmount} {currency}
                              </div>

                              <div className="flex items-center gap-1.5">
                                {isUnpaid ? (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      soundFX.playClick();
                                      setSettleModalData({
                                        customerName: group.customerName,
                                        saleId: sale.id,
                                        amount: sale.totalAmount,
                                        itemsSummary: sale.items.map((i) => `${i.quantity}x ${i.productName}`).join(', '),
                                      });
                                    }}
                                    className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-xs shadow transition active:scale-95 flex items-center gap-1"
                                  >
                                    <Check className="w-3 h-3" />
                                    <span>Pagar</span>
                                  </button>
                                ) : (
                                  <span className="text-emerald-400 text-xs font-semibold flex items-center gap-1">
                                    <CheckCircle2 className="w-3.5 h-3.5" />
                                    Pago
                                  </span>
                                )}

                                {/* Reverse/Cancel sale */}
                                <button
                                  type="button"
                                  onClick={() => {
                                    if (confirm(`Deseja estornar/cancelar este fiado de ${sale.totalAmount} ${currency}? As bebidas serão repostas no stock.`)) {
                                      onReverseSale(sale.id);
                                    }
                                  }}
                                  className="p-1 rounded text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition"
                                  title="Estornar / Anular fiado"
                                >
                                  <RotateCcw className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ) : (
        /* 2. Detailed Flat Table View */
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-md">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/80 text-slate-400 uppercase text-[10px] font-bold border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Data/Hora</th>
                  <th className="py-3 px-4">Nome do Cliente</th>
                  <th className="py-3 px-4">Bebidas / Consumo</th>
                  <th className="py-3 px-4">Estado</th>
                  <th className="py-3 px-4 text-right">Valor</th>
                  <th className="py-3 px-4 text-center">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {filteredSales.map((sale) => {
                  const isUnpaid = sale.isPaid !== true;
                  return (
                    <tr key={sale.id} className="hover:bg-slate-850/60 transition">
                      <td className="py-3 px-4 font-mono text-[11px] text-slate-400 whitespace-nowrap">
                        {sale.dateStr} <span className="text-slate-500">{sale.timeStr}</span>
                      </td>
                      <td className="py-3 px-4 font-semibold text-slate-100">
                        <div className="flex items-center gap-1.5">
                          <User className="w-3.5 h-3.5 text-purple-400" />
                          <span>{sale.customerName || 'Cliente sem nome'}</span>
                        </div>
                        {sale.customerPhone && (
                          <div className="text-[10px] text-slate-400 flex items-center gap-1">
                            <Phone className="w-2.5 h-2.5" />
                            {sale.customerPhone}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4 text-slate-200">
                        {sale.items.map((i) => `${i.quantity}x ${i.productName}`).join(' + ')}
                        {sale.notes && (
                          <div className="text-[10px] text-slate-400 italic">{sale.notes}</div>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        {isUnpaid ? (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                            Pendente (Não Pago)
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                            Liquidado ({sale.settlementMethod ? getPaymentMethodShortLabel(sale.settlementMethod) : 'Pago'})
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right font-display font-bold text-sm text-purple-300">
                        {sale.totalAmount} {currency}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          {isUnpaid && (
                            <button
                              type="button"
                              onClick={() => {
                                soundFX.playClick();
                                setSettleModalData({
                                  customerName: sale.customerName || 'Cliente',
                                  saleId: sale.id,
                                  amount: sale.totalAmount,
                                  itemsSummary: sale.items.map((i) => `${i.quantity}x ${i.productName}`).join(', '),
                                });
                              }}
                              className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-xs shadow transition"
                            >
                              Pagar
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => {
                              if (confirm(`Deseja estornar/cancelar esta venda de fiado?`)) {
                                onReverseSale(sale.id);
                              }
                            }}
                            className="p-1 text-slate-500 hover:text-rose-400 rounded transition"
                            title="Estornar"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODAL 1: REGISTAR NOVA DÍVIDA / FIADO */}
      {isNewDebtModalOpen && (
        <NewDebtModal
          products={products}
          currency={currency}
          knownCustomers={knownCustomers}
          onClose={() => setIsNewDebtModalOpen(false)}
          onConfirm={(data) => {
            onRegisterSale(
              data.product,
              data.quantity,
              data.unitPrice,
              'fiado',
              data.customerName,
              data.notes,
              data.customerPhone,
              data.dueDate
            );
            setIsNewDebtModalOpen(false);
          }}
        />
      )}

      {/* MODAL 2: LIQUIDAR / PAGAR CONTA */}
      {settleModalData && (
        <SettleDebtModal
          data={settleModalData}
          currency={currency}
          onClose={() => setSettleModalData(null)}
          onConfirm={({ settlementMethod, notes }) => {
            if (settleModalData.saleId) {
              onSettleDebt(settleModalData.saleId, settlementMethod, notes);
            } else {
              onSettleAllCustomerDebts(settleModalData.customerName, settlementMethod, notes);
            }
            setSettleModalData(null);
          }}
        />
      )}
    </div>
  );
};

// ==========================================
// SUB-COMPONENT: MODAL REGISTAR NOVA DÍVIDA
// ==========================================
interface NewDebtModalProps {
  products: Product[];
  currency: string;
  knownCustomers: { name: string; phone?: string; totalDebts: number }[];
  onClose: () => void;
  onConfirm: (data: {
    product: Product;
    quantity: number;
    unitPrice: number;
    customerName: string;
    customerPhone?: string;
    dueDate?: string;
    notes?: string;
  }) => void;
}

const NewDebtModal: React.FC<NewDebtModalProps> = ({
  products,
  currency,
  knownCustomers,
  onClose,
  onConfirm,
}) => {
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [selectedProductId, setSelectedProductId] = useState<string>(products[0]?.id || '');
  const [customDrinkName, setCustomDrinkName] = useState('');
  const [quantity, setQuantity] = useState<number>(1);
  const [unitPrice, setUnitPrice] = useState<number>(products[0]?.sellPrice || 50);
  const [dueDate, setDueDate] = useState('');
  const [notes, setNotes] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);

  // Selected product object
  const selectedProduct = useMemo(() => {
    return products.find((p) => p.id === selectedProductId);
  }, [products, selectedProductId]);

  // When changing product, auto update default unit price
  const handleSelectProduct = (prodId: string) => {
    setSelectedProductId(prodId);
    const prod = products.find((p) => p.id === prodId);
    if (prod) {
      setUnitPrice(prod.sellPrice);
    }
  };

  // Filter customer suggestions based on typing
  const filteredSuggestions = useMemo(() => {
    if (!customerName.trim()) return [];
    return knownCustomers.filter((c) =>
      c.name.toLowerCase().includes(customerName.toLowerCase())
    );
  }, [knownCustomers, customerName]);

  const handleSelectSuggestion = (c: { name: string; phone?: string }) => {
    setCustomerName(c.name);
    if (c.phone) setCustomerPhone(c.phone);
    setShowSuggestions(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!customerName.trim()) {
      alert('Por favor, informe o nome do cliente para registar na caderneta de dívidas.');
      return;
    }

    if (quantity <= 0) {
      alert('A quantidade deve ser pelo menos 1.');
      return;
    }

    if (unitPrice < 0) {
      alert('Preço unitário inválido.');
      return;
    }

    let targetProduct = selectedProduct;

    // If no stock product exists, create a transient item
    if (!targetProduct) {
      targetProduct = {
        id: `temp-prod-${Date.now()}`,
        name: customDrinkName.trim() || 'Bebida / Consumo Diversos',
        category: 'Cerveja',
        costPrice: 0,
        sellPrice: unitPrice,
        currentStock: 999,
        minStockAlert: 0,
        totalSold: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
    }

    soundFX.playSaleChime();
    onConfirm({
      product: targetProduct,
      quantity,
      unitPrice,
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim() || undefined,
      dueDate: dueDate.trim() || undefined,
      notes: notes.trim() || undefined,
    });
  };

  const totalAmount = quantity * unitPrice;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="w-full max-w-lg bg-slate-900 border border-purple-500/50 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-slate-800/90 px-5 py-4 border-b border-slate-700/60 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-display font-bold text-sm text-white">
                Registar Conta Não Paga (Fiado)
              </h3>
              <p className="text-[11px] text-slate-400">
                Adicionar consumo fiado com identificação do cliente
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700/60 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto">
          {/* Customer Identification */}
          <div className="space-y-3 p-3.5 rounded-xl bg-purple-950/20 border border-purple-500/30">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold text-purple-300">
                Nome do Cliente <span className="text-red-400">*</span>
              </label>
              <span className="text-[10px] text-slate-400">Obrigatório para controlo</span>
            </div>

            <div className="relative">
              <input
                type="text"
                required
                placeholder="Ex: Carlos Mabote, Nelson, Mesa 4..."
                value={customerName}
                onChange={(e) => {
                  setCustomerName(e.target.value);
                  setShowSuggestions(true);
                }}
                onFocus={() => setShowSuggestions(true)}
                className="w-full bg-slate-950 border border-purple-500/50 rounded-xl px-3 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-purple-400"
              />

              {/* Suggestions Dropdown */}
              {showSuggestions && filteredSuggestions.length > 0 && (
                <div className="absolute left-0 right-0 top-full mt-1 bg-slate-900 border border-slate-700 rounded-xl shadow-xl z-20 overflow-hidden max-h-36 overflow-y-auto">
                  {filteredSuggestions.map((c) => (
                    <button
                      key={c.name}
                      type="button"
                      onClick={() => handleSelectSuggestion(c)}
                      className="w-full text-left px-3 py-2 text-xs hover:bg-purple-600/30 text-slate-200 flex items-center justify-between border-b border-slate-800 last:border-0"
                    >
                      <span className="font-semibold">{c.name}</span>
                      {c.phone && <span className="text-slate-400 text-[10px]">{c.phone}</span>}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Customer Phone (Optional) */}
            <div>
              <label className="block text-[11px] font-medium text-slate-300 mb-1">
                Telefone / WhatsApp (Opcional - para cobrar direto)
              </label>
              <input
                type="tel"
                placeholder="Ex: 84 123 4567"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-400"
              />
            </div>
          </div>

          {/* Drink Selection */}
          <div className="space-y-3">
            <label className="block text-xs font-bold text-slate-200">
              Bebida ou Consumo do Bar
            </label>

            {products.length > 0 ? (
              <select
                value={selectedProductId}
                onChange={(e) => handleSelectProduct(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-white focus:outline-none focus:border-purple-400"
              >
                {products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.sellPrice} {currency}) - Stock: {p.currentStock} un.
                  </option>
                ))}
              </select>
            ) : (
              <div>
                <input
                  type="text"
                  placeholder="Nome da bebida (ex: Cerveja 2M, Heineken, etc.)"
                  value={customDrinkName}
                  onChange={(e) => setCustomDrinkName(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-400"
                />
              </div>
            )}
          </div>

          {/* Quantity & Unit Price */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                Quantidade
              </label>
              <div className="flex items-center gap-1.5 bg-slate-800 border border-slate-700 rounded-xl p-1">
                <button
                  type="button"
                  onClick={() => setQuantity((prev) => Math.max(1, prev - 1))}
                  className="w-8 h-8 rounded-lg bg-slate-700 hover:bg-slate-600 text-white font-bold flex items-center justify-center transition"
                >
                  -
                </button>
                <input
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value, 10) || 1))}
                  className="w-full text-center bg-transparent text-white font-bold text-sm focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => setQuantity((prev) => prev + 1)}
                  className="w-8 h-8 rounded-lg bg-slate-700 hover:bg-slate-600 text-white font-bold flex items-center justify-center transition"
                >
                  +
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                Preço Unitário ({currency})
              </label>
              <input
                type="number"
                min="0"
                step="1"
                value={unitPrice}
                onChange={(e) => setUnitPrice(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-bold focus:outline-none focus:border-purple-400"
              />
            </div>
          </div>

          {/* Due Date & Notes */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Data Prevista p/ Pagar
              </label>
              <input
                type="text"
                placeholder="Ex: Sexta-feira, Fim do mês"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-400"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Notas / Observações
              </label>
              <input
                type="text"
                placeholder="Ex: Amigo do gerente, mesa 2..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-400"
              />
            </div>
          </div>

          {/* Subtotal Box */}
          <div className="p-3 bg-purple-950/30 border border-purple-500/30 rounded-xl flex items-center justify-between">
            <span className="text-xs font-bold text-purple-300">Total a Registar em Dívida:</span>
            <span className="font-display font-black text-xl text-purple-300">
              {totalAmount.toLocaleString('pt-PT')} {currency}
            </span>
          </div>

          {/* Submit Buttons */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white transition"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-display font-bold text-xs shadow-md transition active:scale-95 flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>Registar Fiado na Caderneta</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// ==========================================
// SUB-COMPONENT: MODAL LIQUIDAR / PAGAR DÍVIDA
// ==========================================
interface SettleDebtModalProps {
  data: {
    customerName: string;
    saleId?: string;
    amount: number;
    itemsSummary: string;
  };
  currency: string;
  onClose: () => void;
  onConfirm: (payload: { settlementMethod: PaymentMethod; notes?: string }) => void;
}

const SettleDebtModal: React.FC<SettleDebtModalProps> = ({
  data,
  currency,
  onClose,
  onConfirm,
}) => {
  const [settlementMethod, setSettlementMethod] = useState<PaymentMethod>('mpesa');
  const [notes, setNotes] = useState('');

  const handleConfirm = () => {
    soundFX.playSaleChime();
    onConfirm({ settlementMethod, notes });
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="w-full max-w-md bg-slate-900 border border-emerald-500/50 rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="bg-slate-800/90 px-5 py-4 border-b border-slate-700/60 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-display font-bold text-sm text-white">
                Liquidar / Receber Dívida
              </h3>
              <p className="text-[11px] text-slate-400">
                Cliente: <span className="font-semibold text-slate-200">{data.customerName}</span>
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          {/* Amount to receive banner */}
          <div className="p-4 bg-emerald-950/30 border border-emerald-500/40 rounded-xl text-center space-y-1">
            <span className="text-xs text-emerald-400 font-semibold">Valor a Receber / Liquidar</span>
            <div className="font-display font-black text-3xl text-emerald-400">
              {data.amount.toLocaleString('pt-PT')} <span className="text-sm font-normal">{currency}</span>
            </div>
            <div className="text-[11px] text-slate-400">{data.itemsSummary}</div>
          </div>

          {/* Payment Method Selector */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-200">
              Como o cliente está a pagar esta dívida hoje?
            </label>

            <div className="grid grid-cols-2 gap-2">
              {/* 1. Físico */}
              <button
                type="button"
                onClick={() => setSettlementMethod('fisico')}
                className={`p-2.5 rounded-xl border flex items-center gap-2 text-left transition ${
                  settlementMethod === 'fisico' || settlementMethod === 'dinheiro'
                    ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 ring-1 ring-emerald-500/50'
                    : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-750'
                }`}
              >
                <Banknote className="w-4 h-4 text-emerald-400 shrink-0" />
                <div>
                  <div className="text-xs font-bold">Físico</div>
                  <div className="text-[10px] text-slate-400">Dinheiro / Gaveta</div>
                </div>
              </button>

              {/* 2. e-Mola */}
              <button
                type="button"
                onClick={() => setSettlementMethod('emola')}
                className={`p-2.5 rounded-xl border flex items-center gap-2 text-left transition ${
                  settlementMethod === 'emola'
                    ? 'bg-orange-500/20 border-orange-500 text-orange-300 ring-1 ring-orange-500/50'
                    : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-750'
                }`}
              >
                <Smartphone className="w-4 h-4 text-orange-400 shrink-0" />
                <div>
                  <div className="text-xs font-bold">e-Mola</div>
                  <div className="text-[10px] text-orange-400/80 font-medium">Movitel</div>
                </div>
              </button>

              {/* 3. M-Pesa */}
              <button
                type="button"
                onClick={() => setSettlementMethod('mpesa')}
                className={`p-2.5 rounded-xl border flex items-center gap-2 text-left transition ${
                  settlementMethod === 'mpesa' || settlementMethod === 'mpesa_emola'
                    ? 'bg-red-500/20 border-red-500 text-red-300 ring-1 ring-red-500/50'
                    : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-750'
                }`}
              >
                <Smartphone className="w-4 h-4 text-red-400 shrink-0" />
                <div>
                  <div className="text-xs font-bold">M-Pesa</div>
                  <div className="text-[10px] text-red-400/80 font-medium">Vodacom</div>
                </div>
              </button>

              {/* 4. M-Kash */}
              <button
                type="button"
                onClick={() => setSettlementMethod('mkash')}
                className={`p-2.5 rounded-xl border flex items-center gap-2 text-left transition ${
                  settlementMethod === 'mkash'
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300 ring-1 ring-amber-500/50'
                    : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-750'
                }`}
              >
                <Smartphone className="w-4 h-4 text-amber-400 shrink-0" />
                <div>
                  <div className="text-xs font-bold">M-Kash</div>
                  <div className="text-[10px] text-amber-400/80 font-medium">Tmcel</div>
                </div>
              </button>
            </div>

            {/* Cartão option */}
            <button
              type="button"
              onClick={() => setSettlementMethod('cartao')}
              className={`w-full p-2 rounded-xl border flex items-center gap-2 text-left transition text-xs mt-1 ${
                settlementMethod === 'cartao'
                  ? 'bg-blue-500/20 border-blue-500 text-blue-300 ring-1 ring-blue-500/50'
                  : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-750'
              }`}
            >
              <CreditCard className="w-4 h-4 text-blue-400" />
              <span>Cartão / POS Terminal Bancário</span>
            </button>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Notas do Pagamento (Opcional)
            </label>
            <input
              type="text"
              placeholder="Ex: Recebido pelo M-Pesa de 84xxxxxxx"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400"
            />
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white transition"
            >
              Cancelar
            </button>
            <button
              type="button"
              onClick={handleConfirm}
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-display font-black text-xs shadow-md transition active:scale-95 flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>Confirmar Liquidação</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
