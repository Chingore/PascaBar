import React, { useState, useMemo } from 'react';
import { Sale, CashClosure, Expense } from '../types';
import { normalizePaymentMethod, PAYMENT_CONFIGS } from '../utils/payment';
import { 
  Calendar, 
  DollarSign, 
  TrendingUp, 
  TrendingDown, 
  Plus, 
  Receipt, 
  Share2, 
  Printer, 
  Layers, 
  Tag, 
  CheckCircle2, 
  AlertCircle,
  BarChart3,
  Banknote,
  Smartphone,
  CreditCard,
  Clock
} from 'lucide-react';

interface MonthlyCashFlowViewProps {
  sales: Sale[];
  closures: CashClosure[];
  expenses: Expense[];
  currency: string;
  barName: string;
  onAddExpense: (expense: Omit<Expense, 'id' | 'timestamp'>) => void;
  onDeleteExpense: (expenseId: string) => void;
}

export const MonthlyCashFlowView: React.FC<MonthlyCashFlowViewProps> = ({
  sales,
  closures,
  expenses,
  currency,
  barName,
  onAddExpense,
  onDeleteExpense,
}) => {
  // Current Year-Month default
  const today = new Date();
  const defaultYearMonth = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;
  const [selectedYearMonth, setSelectedYearMonth] = useState<string>(defaultYearMonth);

  // Expense modal
  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState(false);
  const [expenseDesc, setExpenseDesc] = useState('');
  const [expenseAmount, setExpenseAmount] = useState<number>(200);
  const [expenseCategory, setExpenseCategory] = useState<'gelo' | 'reposicao' | 'energia' | 'salario' | 'limpeza' | 'outro'>('gelo');
  const [expenseDate, setExpenseDate] = useState<string>(today.toISOString().split('T')[0]);

  // Filter sales, closures and expenses for the selected month
  const monthSales = useMemo(() => {
    return sales.filter((s) => !s.isReversed && s.dateStr.startsWith(selectedYearMonth));
  }, [sales, selectedYearMonth]);

  const monthExpenses = useMemo(() => {
    return expenses.filter((e) => e.dateStr.startsWith(selectedYearMonth));
  }, [expenses, selectedYearMonth]);

  const monthClosures = useMemo(() => {
    return closures.filter((c) => c.dateStr.startsWith(selectedYearMonth));
  }, [closures, selectedYearMonth]);

  // Consolidated monthly metrics
  const totalRevenue = useMemo(() => monthSales.reduce((sum, s) => sum + s.totalAmount, 0), [monthSales]);
  const totalCostOfGoods = useMemo(() => monthSales.reduce((sum, s) => sum + s.totalCost, 0), [monthSales]);
  const totalOperationalExpenses = useMemo(() => monthExpenses.reduce((sum, e) => sum + e.amount, 0), [monthExpenses]);
  const netMonthlyProfit = totalRevenue - totalCostOfGoods - totalOperationalExpenses;
  const totalDrinksSold = useMemo(
    () => monthSales.reduce((sum, s) => sum + s.items.reduce((iSum, i) => iSum + i.quantity, 0), 0),
    [monthSales]
  );

  // Consolidated monthly payment breakdown
  const monthlyPaymentBreakdown = useMemo(() => {
    const acc = { fisico: 0, emola: 0, mpesa: 0, mkash: 0, cartao: 0, fiado: 0, outro: 0 };
    monthSales.forEach((s) => {
      const norm = normalizePaymentMethod(s.paymentMethod);
      acc[norm] = (acc[norm] || 0) + s.totalAmount;
    });
    return acc;
  }, [monthSales]);

  // Group by day of month
  const dailyDataMap = useMemo(() => {
    const map: Record<string, {
      dateStr: string;
      day: number;
      revenue: number;
      cost: number;
      expenses: number;
      drinks: number;
      salesCount: number;
      isClosed: boolean;
    }> = {};

    // Populate from sales
    monthSales.forEach((s) => {
      if (!map[s.dateStr]) {
        map[s.dateStr] = {
          dateStr: s.dateStr,
          day: parseInt(s.dateStr.split('-')[2], 10),
          revenue: 0,
          cost: 0,
          expenses: 0,
          drinks: 0,
          salesCount: 0,
          isClosed: false,
        };
      }
      map[s.dateStr].revenue += s.totalAmount;
      map[s.dateStr].cost += s.totalCost;
      map[s.dateStr].salesCount += 1;
      map[s.dateStr].drinks += s.items.reduce((acc, i) => acc + i.quantity, 0);
    });

    // Add expenses
    monthExpenses.forEach((e) => {
      if (!map[e.dateStr]) {
        map[e.dateStr] = {
          dateStr: e.dateStr,
          day: parseInt(e.dateStr.split('-')[2], 10),
          revenue: 0,
          cost: 0,
          expenses: 0,
          drinks: 0,
          salesCount: 0,
          isClosed: false,
        };
      }
      map[e.dateStr].expenses += e.amount;
    });

    // Check closures
    monthClosures.forEach((c) => {
      if (map[c.dateStr]) {
        map[c.dateStr].isClosed = true;
      }
    });

    return Object.values(map).sort((a, b) => b.dateStr.localeCompare(a.dateStr));
  }, [monthSales, monthExpenses, monthClosures]);

  const activeDaysCount = dailyDataMap.length || 1;
  const averageDailyRevenue = Math.round(totalRevenue / activeDaysCount);
  const averageDailyProfit = Math.round(netMonthlyProfit / activeDaysCount);

  // Handle Add Expense
  const handleSaveExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!expenseDesc.trim()) {
      alert('Por favor insira a descrição da despesa.');
      return;
    }
    if (expenseAmount <= 0) {
      alert('O valor deve ser maior que zero.');
      return;
    }

    onAddExpense({
      dateStr: expenseDate,
      description: expenseDesc.trim(),
      amount: expenseAmount,
      category: expenseCategory,
    });

    setExpenseDesc('');
    setIsExpenseModalOpen(false);
  };

  // WhatsApp share monthly report
  const generateWhatsAppMonthlyReport = () => {
    const [year, month] = selectedYearMonth.split('-');
    const monthNames = [
      'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
      'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
    ];
    const monthName = monthNames[parseInt(month, 10) - 1] || month;

    const text = `📊 *FLUXO DE CAIXA MENSAL - ${barName.toUpperCase()}*\n🗓 Período: ${monthName} de ${year}\n----------------------------------\n📈 *Faturação Total (Receitas):* ${totalRevenue.toLocaleString('pt-PT')} ${currency}\n📉 *Custo Bebidas (CMV):* ${totalCostOfGoods.toLocaleString('pt-PT')} ${currency}\n💸 *Despesas do Bar (Gelo, etc.):* ${totalOperationalExpenses.toLocaleString('pt-PT')} ${currency}\n💎 *LUCRO LÍQUIDO MENSAL:* ${netMonthlyProfit.toLocaleString('pt-PT')} ${currency}\n\n*Entradas por Canal no Mês:*\n💵 Físico (Dinheiro): ${monthlyPaymentBreakdown.fisico.toLocaleString('pt-PT')} ${currency}\n🟠 e-Mola (Movitel): ${monthlyPaymentBreakdown.emola.toLocaleString('pt-PT')} ${currency}\n🔴 M-Pesa (Vodacom): ${monthlyPaymentBreakdown.mpesa.toLocaleString('pt-PT')} ${currency}\n🟡 M-Kash (Tmcel): ${monthlyPaymentBreakdown.mkash.toLocaleString('pt-PT')} ${currency}\n💳 Cartão / POS: ${monthlyPaymentBreakdown.cartao.toLocaleString('pt-PT')} ${currency}\n⏳ Fiados: ${monthlyPaymentBreakdown.fiado.toLocaleString('pt-PT')} ${currency}\n\n🍹 *Total Bebidas Vendidas:* ${totalDrinksSold} un.\n📆 *Dias com Movimento:* ${dailyDataMap.length} dias\n⚡ *Média Faturação/Dia:* ${averageDailyRevenue.toLocaleString('pt-PT')} ${currency}\n💰 *Média Lucro/Dia:* ${averageDailyProfit.toLocaleString('pt-PT')} ${currency}\n----------------------------------\n_Gerado automaticamente por PascBar_`;

    return encodeURIComponent(text);
  };

  return (
    <div className="space-y-4">
      {/* Month Selector Bar & Actions */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4 shadow-md">
        <div className="flex items-center gap-3">
          <Calendar className="w-5 h-5 text-amber-400" />
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
              Mês de Análise
            </span>
            <input
              type="month"
              value={selectedYearMonth}
              onChange={(e) => setSelectedYearMonth(e.target.value)}
              className="block bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1 text-xs font-bold text-white focus:outline-none focus:border-amber-400"
            />
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Add Expense Button */}
          <button
            type="button"
            id="open-add-expense-btn"
            onClick={() => setIsExpenseModalOpen(true)}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition flex items-center gap-1.5 border border-slate-700"
          >
            <Plus className="w-3.5 h-3.5 text-amber-400" />
            <span>Registar Despesa (Gelo, Energia...)</span>
          </button>

          {/* Share WhatsApp */}
          <a
            href={`https://wa.me/?text=${generateWhatsAppMonthlyReport()}`}
            target="_blank"
            rel="noreferrer"
            className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-display font-bold text-xs shadow-md shadow-emerald-950/40 flex items-center gap-1.5 transition"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>Partilhar no WhatsApp</span>
          </a>
        </div>
      </div>

      {/* Monthly KPIs: Receitas, CMV, Despesas, Lucro Líquido Consolidado */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Receita Bruta */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase">
            <span>Entradas / Vendas do Mês</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="font-display font-black text-2xl text-slate-100 mt-1">
            {totalRevenue.toLocaleString('pt-PT')} <span className="text-xs font-medium text-slate-400">{currency}</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Média: {averageDailyRevenue.toLocaleString('pt-PT')} {currency}/dia
          </div>
        </div>

        {/* Custo de Bebidas */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase">
            <span>Custo Mercadoria (CMV)</span>
            <TrendingDown className="w-4 h-4 text-rose-400" />
          </div>
          <div className="font-display font-black text-2xl text-rose-400 mt-1">
            {totalCostOfGoods.toLocaleString('pt-PT')} <span className="text-xs font-medium text-slate-400">{currency}</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Total gasto na compra das bebidas
          </div>
        </div>

        {/* Despesas do Bar */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase">
            <span>Despesas Extras do Bar</span>
            <Receipt className="w-4 h-4 text-amber-400" />
          </div>
          <div className="font-display font-black text-2xl text-amber-400 mt-1">
            {totalOperationalExpenses.toLocaleString('pt-PT')} <span className="text-xs font-medium text-slate-400">{currency}</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {monthExpenses.length} despesas registadas (gelo, etc.)
          </div>
        </div>

        {/* Lucro Líquido Consolidado */}
        <div className="bg-gradient-to-br from-emerald-950/40 via-slate-900 to-emerald-900/20 border-2 border-emerald-500/70 rounded-2xl p-4 shadow-lg shadow-emerald-950/40">
          <div className="flex items-center justify-between text-emerald-300 text-xs font-bold uppercase tracking-wider">
            <span>Lucro Líquido Consolidado</span>
            <span className="text-lg">💎</span>
          </div>
          <div className="font-display font-black text-3xl text-emerald-400 mt-1">
            +{netMonthlyProfit.toLocaleString('pt-PT')} <span className="text-xs font-bold text-emerald-300">{currency}</span>
          </div>
          <div className="text-[11px] text-emerald-300/80 mt-1 font-semibold">
            Saldo real limpo para o dono do bar
          </div>
        </div>
      </div>

      {/* Monthly Payment Channels Breakdown */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h4 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2">
            <Banknote className="w-4 h-4 text-emerald-400" />
            Canais de Recebimento no Mês
          </h4>
          <span className="text-xs text-amber-400 font-semibold">
            M-Pesa + e-Mola + M-Kash: {((monthlyPaymentBreakdown.emola || 0) + (monthlyPaymentBreakdown.mpesa || 0) + (monthlyPaymentBreakdown.mkash || 0)).toLocaleString('pt-PT')} {currency}
          </span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2.5">
          {/* Físico */}
          <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60">
            <div className="flex items-center gap-1.5 mb-1">
              <Banknote className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-bold text-slate-200">Físico</span>
            </div>
            <div className="font-display font-black text-lg text-emerald-400">
              {monthlyPaymentBreakdown.fisico.toLocaleString('pt-PT')}
            </div>
            <div className="text-[10px] text-slate-400">
              {totalRevenue > 0 ? Math.round((monthlyPaymentBreakdown.fisico / totalRevenue) * 100) : 0}% do total
            </div>
          </div>

          {/* e-Mola */}
          <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60">
            <div className="flex items-center gap-1.5 mb-1">
              <Smartphone className="w-4 h-4 text-orange-400" />
              <span className="text-xs font-bold text-slate-200">e-Mola</span>
            </div>
            <div className="font-display font-black text-lg text-orange-400">
              {monthlyPaymentBreakdown.emola.toLocaleString('pt-PT')}
            </div>
            <div className="text-[10px] text-orange-400/80 font-medium">Movitel</div>
          </div>

          {/* M-Pesa */}
          <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60">
            <div className="flex items-center gap-1.5 mb-1">
              <Smartphone className="w-4 h-4 text-red-400" />
              <span className="text-xs font-bold text-slate-200">M-Pesa</span>
            </div>
            <div className="font-display font-black text-lg text-red-400">
              {monthlyPaymentBreakdown.mpesa.toLocaleString('pt-PT')}
            </div>
            <div className="text-[10px] text-red-400/80 font-medium">Vodacom</div>
          </div>

          {/* M-Kash */}
          <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60">
            <div className="flex items-center gap-1.5 mb-1">
              <Smartphone className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-bold text-slate-200">M-Kash</span>
            </div>
            <div className="font-display font-black text-lg text-amber-400">
              {monthlyPaymentBreakdown.mkash.toLocaleString('pt-PT')}
            </div>
            <div className="text-[10px] text-amber-400/80 font-medium">Tmcel</div>
          </div>

          {/* Cartão */}
          <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60">
            <div className="flex items-center gap-1.5 mb-1">
              <CreditCard className="w-4 h-4 text-blue-400" />
              <span className="text-xs font-bold text-slate-200">Cartão/POS</span>
            </div>
            <div className="font-display font-black text-lg text-blue-400">
              {monthlyPaymentBreakdown.cartao.toLocaleString('pt-PT')}
            </div>
            <div className="text-[10px] text-slate-400">Terminal</div>
          </div>

          {/* Fiados */}
          <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60">
            <div className="flex items-center gap-1.5 mb-1">
              <Clock className="w-4 h-4 text-purple-400" />
              <span className="text-xs font-bold text-slate-200">Fiados</span>
            </div>
            <div className="font-display font-black text-lg text-purple-400">
              {monthlyPaymentBreakdown.fiado.toLocaleString('pt-PT')}
            </div>
            <div className="text-[10px] text-purple-400/80 font-medium">Pendentes</div>
          </div>
        </div>
      </div>

      {/* Mini Visual Bar Chart of Daily Revenue in Month */}
      {dailyDataMap.length > 0 && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-amber-400" />
              Evolução Diária do Faturamento no Mês
            </h4>
            <span className="text-xs text-slate-400">
              Total: {totalDrinksSold} bebidas servidas
            </span>
          </div>

          <div className="pt-4 pb-2 flex items-end gap-1.5 h-36 overflow-x-auto">
            {dailyDataMap
              .slice()
              .reverse()
              .map((d) => {
                const maxRev = Math.max(...dailyDataMap.map((item) => item.revenue), 100);
                const heightPct = Math.max(8, Math.round((d.revenue / maxRev) * 100));
                const dayProfit = d.revenue - d.cost - d.expenses;

                return (
                  <div
                    key={d.dateStr}
                    className="flex-1 min-w-[28px] flex flex-col items-center justify-end h-full group relative"
                  >
                    {/* Tooltip on hover */}
                    <div className="absolute -top-10 opacity-0 group-hover:opacity-100 pointer-events-none transition bg-slate-950 border border-slate-700 px-2 py-1 rounded text-[10px] text-white whitespace-nowrap z-20 shadow-lg">
                      Dia {d.day}: {d.revenue} {currency} (Lucro: +{dayProfit})
                    </div>

                    <div
                      style={{ height: `${heightPct}%` }}
                      className="w-full bg-gradient-to-t from-amber-600 to-amber-400 rounded-t group-hover:from-emerald-500 group-hover:to-emerald-400 transition"
                    />
                    <span className="text-[10px] font-mono text-slate-400 mt-1.5">
                      {d.day}
                    </span>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* Daily Consolidated Breakdown Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-lg">
        <div className="px-4 py-3 bg-slate-800/80 border-b border-slate-800 flex items-center justify-between">
          <h4 className="font-display font-bold text-sm text-slate-100">
            Detalhamento Diário Consolidado ({dailyDataMap.length} dias ativos)
          </h4>
        </div>

        {dailyDataMap.length === 0 ? (
          <div className="text-center py-8 text-xs text-slate-400">
            Nenhuma atividade registada neste mês.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-800/40 uppercase tracking-wider text-[11px] text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-4">Data</th>
                  <th className="py-2.5 px-3 text-right">Vendas Brutas</th>
                  <th className="py-2.5 px-3 text-right">Custo Bebidas</th>
                  <th className="py-2.5 px-3 text-right">Despesas Bar</th>
                  <th className="py-2.5 px-3 text-right">Lucro Líquido</th>
                  <th className="py-2.5 px-3 text-center">Bebidas</th>
                  <th className="py-2.5 px-4 text-center">Estado Fecho</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-sans">
                {dailyDataMap.map((d) => {
                  const netDailyProfit = d.revenue - d.cost - d.expenses;

                  return (
                    <tr key={d.dateStr} className="hover:bg-slate-800/30 transition">
                      <td className="py-2.5 px-4 font-bold text-slate-200 font-mono">
                        {d.dateStr}
                      </td>
                      <td className="py-2.5 px-3 text-right font-display font-bold text-amber-400">
                        {d.revenue.toLocaleString('pt-PT')} {currency}
                      </td>
                      <td className="py-2.5 px-3 text-right text-rose-400 font-mono">
                        {d.cost.toLocaleString('pt-PT')} {currency}
                      </td>
                      <td className="py-2.5 px-3 text-right text-amber-300 font-mono">
                        {d.expenses > 0 ? `${d.expenses} ${currency}` : '-'}
                      </td>
                      <td className="py-2.5 px-3 text-right font-display font-bold text-emerald-400 text-sm">
                        +{netDailyProfit.toLocaleString('pt-PT')} {currency}
                      </td>
                      <td className="py-2.5 px-3 text-center text-slate-300 font-medium">
                        {d.drinks} un.
                      </td>
                      <td className="py-2.5 px-4 text-center">
                        {d.isClosed ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">
                            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                            Fechado
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 text-[10px]">
                            Aberto
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Expenses List of the Month */}
      {monthExpenses.length > 0 && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3">
          <h4 className="font-display font-bold text-sm text-slate-100 flex items-center justify-between">
            <span>Despesas Extras Lançadas no Mês</span>
            <span className="text-xs text-amber-400 font-bold">
              Total: {totalOperationalExpenses} {currency}
            </span>
          </h4>

          <div className="space-y-2 max-h-48 overflow-y-auto">
            {monthExpenses.map((exp) => (
              <div
                key={exp.id}
                className="flex items-center justify-between p-2.5 bg-slate-800/60 border border-slate-700/60 rounded-xl text-xs"
              >
                <div>
                  <span className="font-semibold text-slate-200">{exp.description}</span>
                  <div className="text-[11px] text-slate-400">
                    {exp.dateStr} • Categoria: {exp.category}
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span className="font-display font-bold text-rose-400">
                    -{exp.amount} {currency}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      if (confirm(`Remover despesa "${exp.description}"?`)) {
                        onDeleteExpense(exp.id);
                      }
                    }}
                    className="text-slate-500 hover:text-rose-400 text-[11px]"
                  >
                    Excluir
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal: Registar Despesa do Bar */}
      {isExpenseModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <h3 className="font-display font-bold text-lg text-slate-100 flex items-center gap-2">
                <Receipt className="w-5 h-5 text-amber-400" />
                Lançar Despesa do Bar
              </h3>
              <button
                onClick={() => setIsExpenseModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveExpense} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 mb-1 font-semibold">
                  Descrição da Despesa *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Compra de Gelo para balcão, Recarga Energia, Limpeza..."
                  value={expenseDesc}
                  onChange={(e) => setExpenseDesc(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white outline-none focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">
                    Valor da Despesa ({currency}) *
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="any"
                    required
                    value={expenseAmount}
                    onChange={(e) => setExpenseAmount(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white outline-none focus:border-amber-400 font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">
                    Categoria
                  </label>
                  <select
                    value={expenseCategory}
                    onChange={(e) => setExpenseCategory(e.target.value as any)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white outline-none focus:border-amber-400"
                  >
                    <option value="gelo">Gelo para Cervejas</option>
                    <option value="energia">Energia / Eletricidade</option>
                    <option value="reposicao">Transporte / Frete</option>
                    <option value="salario">Diária / Pessoal</option>
                    <option value="limpeza">Material de Limpeza</option>
                    <option value="outro">Outra Despesa</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">
                  Data da Despesa
                </label>
                <input
                  type="date"
                  value={expenseDate}
                  onChange={(e) => setExpenseDate(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-amber-400 font-bold"
                />
              </div>

              <div className="flex gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setIsExpenseModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-medium hover:bg-slate-700"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-display font-bold text-xs shadow-md shadow-amber-950/40 flex items-center justify-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>Registar no Fluxo de Caixa</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
