import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { 
  Product, 
  Sale, 
  CashClosure, 
  Expense, 
  BarSettings, 
  LicenseState, 
  PaymentMethod 
} from './types';
import { storageService } from './services/storage';
import { cloudSyncManager, CloudSyncState } from './services/cloudSync';
import { soundFX } from './services/audio';

// Components
import { Navbar, ActiveTab } from './components/Navbar';
import { PosView } from './components/PosView';
import { StockView } from './components/StockView';
import { DebtsView } from './components/DebtsView';
import { DailyReportView } from './components/DailyReportView';
import { MonthlyCashFlowView } from './components/MonthlyCashFlowView';
import { CloudBackupModal } from './components/CloudBackupModal';
import { ActivationModal } from './components/ActivationModal';

export default function App() {
  // Primary States
  const [products, setProducts] = useState<Product[]>(() => storageService.getProducts());
  const [sales, setSales] = useState<Sale[]>(() => storageService.getSales());
  const [closures, setClosures] = useState<CashClosure[]>(() => storageService.getClosures());
  const [expenses, setExpenses] = useState<Expense[]>(() => storageService.getExpenses());
  const [settings, setSettings] = useState<BarSettings>(() => storageService.getSettings());
  const [license, setLicense] = useState<LicenseState>(() => storageService.getLicense());

  // UI States
  const [activeTab, setActiveTab] = useState<ActiveTab>('pos');
  const [selectedDate, setSelectedDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [isCloudModalOpen, setIsCloudModalOpen] = useState(false);
  const [isActivationModalOpen, setIsActivationModalOpen] = useState(false);

  // Cloud Sync State
  const [syncState, setSyncState] = useState<CloudSyncState>({
    isOnline: typeof navigator !== 'undefined' ? navigator.onLine : true,
    isSyncing: false,
    lastSyncTime: null,
    lastSyncSuccess: true,
    errorMessage: null,
  });

  // Subscribe to Cloud Sync Manager
  useEffect(() => {
    const unsubscribe = cloudSyncManager.subscribe((state) => {
      setSyncState(state);
    });
    cloudSyncManager.startAutoSync(25000); // sync every 25 seconds if active
    return () => {
      unsubscribe();
      cloudSyncManager.stopAutoSync();
    };
  }, []);

  // License & 1-Week Trial Calculation
  const { isTrialExpired, daysRemaining } = useMemo(() => {
    if (license.isActivated) {
      return { isTrialExpired: false, daysRemaining: 0 };
    }
    const installTime = new Date(license.installedAt).getTime();
    const now = Date.now();
    const diffMs = now - installTime;
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    const remaining = Math.max(0, (license.trialDays || 7) - diffDays);
    const expired = diffDays >= (license.trialDays || 7);
    return { isTrialExpired: expired, daysRemaining: remaining };
  }, [license]);

  // Alert count for Stock (out of stock or low stock)
  const stockAlertCount = useMemo(() => {
    return products.filter((p) => p.currentStock <= p.minStockAlert).length;
  }, [products]);

  // Sales of the selected day
  const salesOfDay = useMemo(() => {
    return sales.filter((s) => s.dateStr === selectedDate);
  }, [sales, selectedDate]);

  // Save changes to localStorage & trigger background cloud sync
  const triggerAutoSync = useCallback(() => {
    if (settings.autoCloudSync && syncState.isOnline) {
      // Fire and forget non-blocking sync
      cloudSyncManager.syncNow().catch(() => {});
    }
  }, [settings.autoCloudSync, syncState.isOnline]);

  // 1. REGISTER SALE (Point of Sale & Fiados)
  const handleRegisterSale = useCallback(
    (
      product: Product,
      quantity: number,
      unitPrice: number,
      paymentMethod: PaymentMethod,
      customerName?: string,
      notes?: string,
      customerPhone?: string,
      dueDate?: string
    ) => {
      const now = new Date();
      const dateStr = now.toISOString().split('T')[0];
      const timeStr = now.toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' });

      const subtotal = quantity * unitPrice;
      const totalCost = quantity * product.costPrice;
      const totalProfit = subtotal - totalCost;
      const isFiado = paymentMethod === 'fiado';

      const newSale: Sale = {
        id: `sale-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        timestamp: now.toISOString(),
        dateStr,
        timeStr,
        items: [
          {
            productId: product.id,
            productName: product.name,
            quantity,
            unitCost: product.costPrice,
            unitPrice,
            subtotal,
            profit: totalProfit,
          },
        ],
        totalAmount: subtotal,
        totalCost,
        totalProfit,
        paymentMethod,
        customerName: customerName?.trim() || (isFiado ? 'Cliente sem nome' : undefined),
        customerPhone: customerPhone?.trim() || undefined,
        dueDate: dueDate?.trim() || undefined,
        isPaid: !isFiado, // Non-fiado sales are paid immediately; fiados start as unpaid
        notes,
      };

      // 1. Update sales
      const updatedSales = [newSale, ...sales];
      setSales(updatedSales);
      storageService.saveSales(updatedSales);

      // 2. Decrement product stock & increment totalSold (only if valid registered product)
      const updatedProducts = products.map((p) => {
        if (p.id === product.id) {
          const newStock = p.currentStock - quantity;
          if (newStock <= 0) {
            soundFX.playStockAlertBeep();
          }
          return {
            ...p,
            currentStock: newStock,
            totalSold: (p.totalSold || 0) + quantity,
            updatedAt: now.toISOString(),
          };
        }
        return p;
      });

      setProducts(updatedProducts);
      storageService.saveProducts(updatedProducts);

      // 3. Trigger cloud sync
      triggerAutoSync();
    },
    [products, sales, triggerAutoSync]
  );

  // 1.1 SETTLE SPECIFIC DEBT
  const handleSettleDebt = useCallback(
    (saleId: string, settlementMethod: PaymentMethod, notes?: string) => {
      const now = new Date();
      const paidDateStr = now.toISOString().split('T')[0];
      const updatedSales = sales.map((s) => {
        if (s.id === saleId) {
          return {
            ...s,
            isPaid: true,
            paidAt: now.toISOString(),
            paidDateStr,
            settlementMethod,
            notes: notes ? (s.notes ? `${s.notes} | ${notes}` : notes) : s.notes,
          };
        }
        return s;
      });
      setSales(updatedSales);
      storageService.saveSales(updatedSales);
      triggerAutoSync();
      soundFX.playSaleChime();
    },
    [sales, triggerAutoSync]
  );

  // 1.2 SETTLE ALL DEBTS OF A CUSTOMER
  const handleSettleAllCustomerDebts = useCallback(
    (customerName: string, settlementMethod: PaymentMethod, notes?: string) => {
      const now = new Date();
      const paidDateStr = now.toISOString().split('T')[0];
      const target = customerName.trim().toLowerCase();
      const updatedSales = sales.map((s) => {
        if (
          (s.customerName || '').trim().toLowerCase() === target &&
          s.isPaid !== true &&
          !s.isReversed
        ) {
          return {
            ...s,
            isPaid: true,
            paidAt: now.toISOString(),
            paidDateStr,
            settlementMethod,
            notes: notes ? (s.notes ? `${s.notes} | ${notes}` : notes) : s.notes,
          };
        }
        return s;
      });
      setSales(updatedSales);
      storageService.saveSales(updatedSales);
      triggerAutoSync();
      soundFX.playSaleChime();
    },
    [sales, triggerAutoSync]
  );

  // 2. REVERSE / CANCEL SALE
  const handleReverseSale = useCallback(
    (saleId: string) => {
      const targetSale = sales.find((s) => s.id === saleId);
      if (!targetSale || targetSale.isReversed) return;

      const updatedSales = sales.map((s) => (s.id === saleId ? { ...s, isReversed: true } : s));
      setSales(updatedSales);
      storageService.saveSales(updatedSales);

      // Return items to product stock
      const updatedProducts = products.map((p) => {
        const saleItem = targetSale.items.find((i) => i.productId === p.id);
        if (saleItem) {
          return {
            ...p,
            currentStock: p.currentStock + saleItem.quantity,
            totalSold: Math.max(0, (p.totalSold || 0) - saleItem.quantity),
            updatedAt: new Date().toISOString(),
          };
        }
        return p;
      });

      setProducts(updatedProducts);
      storageService.saveProducts(updatedProducts);

      soundFX.playClick();
      triggerAutoSync();
    },
    [products, sales, triggerAutoSync]
  );

  // 3. ADD PRODUCT
  const handleAddProduct = useCallback(
    (data: Omit<Product, 'id' | 'createdAt' | 'updatedAt' | 'totalSold'>) => {
      const now = new Date().toISOString();
      const newProduct: Product = {
        ...data,
        id: `prod-${Date.now()}`,
        totalSold: 0,
        createdAt: now,
        updatedAt: now,
      };

      const updated = [...products, newProduct];
      setProducts(updated);
      storageService.saveProducts(updated);
      triggerAutoSync();
      soundFX.playSaleChime();
    },
    [products, triggerAutoSync]
  );

  // 4. UPDATE PRODUCT
  const handleUpdateProduct = useCallback(
    (product: Product) => {
      const updated = products.map((p) =>
        p.id === product.id ? { ...product, updatedAt: new Date().toISOString() } : p
      );
      setProducts(updated);
      storageService.saveProducts(updated);
      triggerAutoSync();
      soundFX.playClick();
    },
    [products, triggerAutoSync]
  );

  // 5. DELETE PRODUCT
  const handleDeleteProduct = useCallback(
    (productId: string) => {
      const updated = products.filter((p) => p.id !== productId);
      setProducts(updated);
      storageService.saveProducts(updated);
      triggerAutoSync();
      soundFX.playClick();
    },
    [products, triggerAutoSync]
  );

  // 6. RESTOCK PRODUCT
  const handleRestockProduct = useCallback(
    (productId: string, quantityToAdd: number) => {
      const updated = products.map((p) => {
        if (p.id === productId) {
          return {
            ...p,
            currentStock: p.currentStock + quantityToAdd,
            updatedAt: new Date().toISOString(),
          };
        }
        return p;
      });
      setProducts(updated);
      storageService.saveProducts(updated);
      triggerAutoSync();
      soundFX.playSaleChime();
    },
    [products, triggerAutoSync]
  );

  // 7. CASH CLOSURE
  const handleExecuteCashClosure = useCallback(
    (closureData: Omit<CashClosure, 'id' | 'closedAt'>) => {
      const now = new Date().toISOString();
      const newClosure: CashClosure = {
        ...closureData,
        id: `closure-${Date.now()}`,
        closedAt: now,
      };

      // Filter existing closure for date if replacing
      const filtered = closures.filter((c) => c.dateStr !== closureData.dateStr);
      const updated = [newClosure, ...filtered];
      setClosures(updated);
      storageService.saveClosures(updated);
      triggerAutoSync();
    },
    [closures, triggerAutoSync]
  );

  // 8. ADD EXPENSE
  const handleAddExpense = useCallback(
    (expenseData: Omit<Expense, 'id' | 'timestamp'>) => {
      const newExpense: Expense = {
        ...expenseData,
        id: `exp-${Date.now()}`,
        timestamp: new Date().toISOString(),
      };
      const updated = [newExpense, ...expenses];
      setExpenses(updated);
      storageService.saveExpenses(updated);
      triggerAutoSync();
      soundFX.playClick();
    },
    [expenses, triggerAutoSync]
  );

  // 9. DELETE EXPENSE
  const handleDeleteExpense = useCallback(
    (expenseId: string) => {
      const updated = expenses.filter((e) => e.id !== expenseId);
      setExpenses(updated);
      storageService.saveExpenses(updated);
      triggerAutoSync();
    },
    [expenses, triggerAutoSync]
  );

  // 10. UPDATE SETTINGS
  const handleUpdateSettings = useCallback((newSettings: BarSettings) => {
    setSettings(newSettings);
    storageService.saveSettings(newSettings);
    soundFX.enabled = newSettings.soundEnabled;
  }, []);

  // 11. CLEAR ALL RECORDS (Zerar tudo para começar com produtos próprios)
  const handleClearAllRecords = useCallback(() => {
    storageService.clearAllRecords();
    setProducts([]);
    setSales([]);
    setClosures([]);
    setExpenses([]);
    triggerAutoSync();
    soundFX.playClick();
  }, [triggerAutoSync]);

  // 11. TOGGLE SOUND
  const handleToggleSound = useCallback(() => {
    const nextState = !settings.soundEnabled;
    const updated = { ...settings, soundEnabled: nextState };
    setSettings(updated);
    storageService.saveSettings(updated);
    soundFX.enabled = nextState;
    if (nextState) soundFX.playSaleChime();
  }, [settings]);

  // 12. FAST SALE MODE TOGGLE
  const handleToggleFastSaleMode = useCallback(() => {
    const updated = { ...settings, fastSaleMode: !settings.fastSaleMode };
    setSettings(updated);
    storageService.saveSettings(updated);
    soundFX.playClick();
  }, [settings]);

  // 13. ACTIVATE LICENSE (Checks keys: lucia86&@ or 193555)
  const handleActivateLicense = useCallback((keyUsed: string) => {
    const newLicenseState: LicenseState = {
      isActivated: true,
      activatedAt: new Date().toISOString(),
      activationKeyUsed: keyUsed,
      installedAt: license.installedAt,
      trialDays: 7,
    };
    setLicense(newLicenseState);
    storageService.saveLicense(newLicenseState);
    setIsActivationModalOpen(false);
    return true;
  }, [license]);

  // Reload state after cloud or file restore
  const handleDataRestored = useCallback(() => {
    setProducts(storageService.getProducts());
    setSales(storageService.getSales());
    setClosures(storageService.getClosures());
    setExpenses(storageService.getExpenses());
    setSettings(storageService.getSettings());
    setLicense(storageService.getLicense());
    soundFX.playSaleChime();
  }, []);

  // Developer / Testing simulation helpers for 7-day expiration
  const handleSimulateExpiry = useCallback(() => {
    const expiredLicense: LicenseState = {
      ...license,
      isActivated: false,
      installedAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000).toISOString(), // 8 days ago
    };
    setLicense(expiredLicense);
    storageService.saveLicense(expiredLicense);
  }, [license]);

  const handleResetTrial = useCallback(() => {
    const resetLicense: LicenseState = {
      isActivated: false,
      installedAt: new Date().toISOString(),
      trialDays: 7,
    };
    setLicense(resetLicense);
    storageService.saveLicense(resetLicense);
  }, []);

  // Unpaid debts count for navigation badge
  const unpaidDebtsCount = useMemo(() => {
    return sales.filter(
      (s) => !s.isReversed && (s.paymentMethod === 'fiado' || s.isPaid === false) && s.isPaid !== true
    ).length;
  }, [sales]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col antialiased">
      {/* Top Navigation & Status Bar */}
      <Navbar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        barName={settings.barName}
        backupCode={settings.backupCode}
        syncState={syncState}
        license={license}
        daysRemaining={daysRemaining}
        isTrialExpired={isTrialExpired}
        soundEnabled={settings.soundEnabled}
        onToggleSound={handleToggleSound}
        onOpenCloudModal={() => setIsCloudModalOpen(true)}
        onOpenActivationModal={() => setIsActivationModalOpen(true)}
        stockAlertCount={stockAlertCount}
        unpaidDebtsCount={unpaidDebtsCount}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-6 pb-20">
        {/* 1. Point of Sale (Vender / Balcão) */}
        {activeTab === 'pos' && (
          <PosView
            products={products}
            salesToday={salesOfDay}
            currency={settings.currency}
            fastSaleMode={settings.fastSaleMode}
            onToggleFastSaleMode={handleToggleFastSaleMode}
            onRegisterSale={handleRegisterSale}
            onReverseSale={handleReverseSale}
            onOpenRestockModal={() => setActiveTab('stock')}
            onNavigateToDebts={() => setActiveTab('debts')}
          />
        )}

        {/* 2. Stock & Bebidas */}
        {activeTab === 'stock' && (
          <StockView
            products={products}
            currency={settings.currency}
            onAddProduct={handleAddProduct}
            onUpdateProduct={handleUpdateProduct}
            onDeleteProduct={handleDeleteProduct}
            onRestockProduct={handleRestockProduct}
            onClearAllRecords={handleClearAllRecords}
          />
        )}

        {/* 3. Caderneta de Fiados & Contas a Receber (Dívidas com Nomes dos Clientes) */}
        {activeTab === 'debts' && (
          <DebtsView
            sales={sales}
            products={products}
            currency={settings.currency}
            barName={settings.barName}
            onRegisterSale={handleRegisterSale}
            onSettleDebt={handleSettleDebt}
            onSettleAllCustomerDebts={handleSettleAllCustomerDebts}
            onReverseSale={handleReverseSale}
          />
        )}

        {/* 4. Lucro Diário & Fecho de Caixa */}
        {activeTab === 'daily_report' && (
          <DailyReportView
            salesToday={salesOfDay}
            closures={closures}
            currency={settings.currency}
            barName={settings.barName}
            selectedDate={selectedDate}
            onChangeDate={setSelectedDate}
            onReverseSale={handleReverseSale}
            onExecuteCashClosure={handleExecuteCashClosure}
          />
        )}

        {/* 4. Fluxo de Caixa Mensal Consolidado */}
        {activeTab === 'cash_flow' && (
          <MonthlyCashFlowView
            sales={sales}
            closures={closures}
            expenses={expenses}
            currency={settings.currency}
            barName={settings.barName}
            onAddExpense={handleAddExpense}
            onDeleteExpense={handleDeleteExpense}
          />
        )}
      </main>

      {/* Cloud Backup & Lost Phone Recovery Modal */}
      {isCloudModalOpen && (
        <CloudBackupModal
          settings={settings}
          syncState={syncState}
          onClose={() => setIsCloudModalOpen(false)}
          onUpdateSettings={handleUpdateSettings}
          onDataRestored={handleDataRestored}
          onClearAllRecords={handleClearAllRecords}
        />
      )}

      {/* Activation Modal: Forced if 1-week trial is expired, or optional if opened manually */}
      {(isTrialExpired || isActivationModalOpen) && (
        <ActivationModal
          license={license}
          isTrialExpired={isTrialExpired}
          daysRemaining={daysRemaining}
          canDismiss={!isTrialExpired}
          onClose={() => setIsActivationModalOpen(false)}
          onActivate={handleActivateLicense}
          onSimulateExpiry={handleSimulateExpiry}
          onResetTrial={handleResetTrial}
        />
      )}
    </div>
  );
}
