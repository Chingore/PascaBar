import { PaymentMethod } from '../types';

export interface PaymentConfig {
  id: PaymentMethod;
  name: string;
  shortLabel: string;
  provider?: string;
  accentColor: string;
  badgeBg: string;
  badgeBorder: string;
  badgeText: string;
  activeBtnClass: string;
  idleBtnClass: string;
  description: string;
}

export const PAYMENT_CONFIGS: Record<string, PaymentConfig> = {
  fisico: {
    id: 'fisico',
    name: 'Físico (Dinheiro)',
    shortLabel: 'Físico',
    provider: 'Notas e Moedas em Caixa',
    accentColor: '#10b981',
    badgeBg: 'bg-emerald-500/15',
    badgeBorder: 'border-emerald-500/40',
    badgeText: 'text-emerald-300',
    activeBtnClass: 'bg-emerald-500/20 border-emerald-500 text-emerald-300 shadow-md shadow-emerald-950/50',
    idleBtnClass: 'bg-slate-800/80 border-slate-700/80 text-slate-300 hover:bg-slate-800 hover:border-emerald-500/40',
    description: 'Pagamento em dinheiro vivo direto na gaveta do bar',
  },
  emola: {
    id: 'emola',
    name: 'e-Mola',
    shortLabel: 'e-Mola',
    provider: 'Movitel',
    accentColor: '#f97316',
    badgeBg: 'bg-orange-500/15',
    badgeBorder: 'border-orange-500/40',
    badgeText: 'text-orange-300',
    activeBtnClass: 'bg-orange-500/20 border-orange-500 text-orange-300 shadow-md shadow-orange-950/50',
    idleBtnClass: 'bg-slate-800/80 border-slate-700/80 text-slate-300 hover:bg-slate-800 hover:border-orange-500/40',
    description: 'Transferência móvel via carteira e-Mola (Movitel)',
  },
  mpesa: {
    id: 'mpesa',
    name: 'M-Pesa',
    shortLabel: 'M-Pesa',
    provider: 'Vodacom',
    accentColor: '#ef4444',
    badgeBg: 'bg-red-500/15',
    badgeBorder: 'border-red-500/40',
    badgeText: 'text-red-300',
    activeBtnClass: 'bg-red-500/20 border-red-500 text-red-300 shadow-md shadow-red-950/50',
    idleBtnClass: 'bg-slate-800/80 border-slate-700/80 text-slate-300 hover:bg-slate-800 hover:border-red-500/40',
    description: 'Transferência móvel via carteira M-Pesa (Vodacom)',
  },
  mkash: {
    id: 'mkash',
    name: 'M-Kash',
    shortLabel: 'M-Kash',
    provider: 'Tmcel',
    accentColor: '#eab308',
    badgeBg: 'bg-amber-500/15',
    badgeBorder: 'border-amber-500/40',
    badgeText: 'text-amber-300',
    activeBtnClass: 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-md shadow-amber-950/50',
    idleBtnClass: 'bg-slate-800/80 border-slate-700/80 text-slate-300 hover:bg-slate-800 hover:border-amber-500/40',
    description: 'Transferência móvel via carteira M-Kash (Tmcel)',
  },
  cartao: {
    id: 'cartao',
    name: 'Cartão / POS',
    shortLabel: 'Cartão',
    provider: 'Terminal Bancário',
    accentColor: '#3b82f6',
    badgeBg: 'bg-blue-500/15',
    badgeBorder: 'border-blue-500/40',
    badgeText: 'text-blue-300',
    activeBtnClass: 'bg-blue-500/20 border-blue-500 text-blue-300 shadow-md shadow-blue-950/50',
    idleBtnClass: 'bg-slate-800/80 border-slate-700/80 text-slate-300 hover:bg-slate-800 hover:border-blue-500/40',
    description: 'Pagamento por cartão de débito/crédito no terminal POS',
  },
  fiado: {
    id: 'fiado',
    name: 'Fiado (Pendente)',
    shortLabel: 'Fiado',
    provider: 'Conta de Cliente',
    accentColor: '#a855f7',
    badgeBg: 'bg-purple-500/15',
    badgeBorder: 'border-purple-500/40',
    badgeText: 'text-purple-300',
    activeBtnClass: 'bg-purple-500/20 border-purple-500 text-purple-300 shadow-md shadow-purple-950/50',
    idleBtnClass: 'bg-slate-800/80 border-slate-700/80 text-slate-300 hover:bg-slate-800 hover:border-purple-500/40',
    description: 'Conta pendente notada para acerto posterior',
  },
  outro: {
    id: 'outro',
    name: 'Outro',
    shortLabel: 'Outro',
    accentColor: '#94a3b8',
    badgeBg: 'bg-slate-500/15',
    badgeBorder: 'border-slate-500/40',
    badgeText: 'text-slate-300',
    activeBtnClass: 'bg-slate-500/20 border-slate-400 text-slate-200',
    idleBtnClass: 'bg-slate-800/80 border-slate-700 text-slate-400',
    description: 'Outra forma de pagamento acordada',
  },
};

/**
 * Normalizes legacy payment methods to current keys
 */
export function normalizePaymentMethod(method: PaymentMethod | string): 'fisico' | 'emola' | 'mpesa' | 'mkash' | 'cartao' | 'fiado' | 'outro' {
  if (method === 'dinheiro') return 'fisico';
  if (method === 'mpesa_emola') return 'mpesa';
  if (method in PAYMENT_CONFIGS) {
    return method as 'fisico' | 'emola' | 'mpesa' | 'mkash' | 'cartao' | 'fiado' | 'outro';
  }
  return 'outro';
}

/**
 * Get readable label for any payment method
 */
export function getPaymentMethodName(method: PaymentMethod | string): string {
  const normalized = normalizePaymentMethod(method);
  return PAYMENT_CONFIGS[normalized]?.name || 'Outro';
}

/**
 * Get short label (ideal for small tags/badges)
 */
export function getPaymentMethodShortLabel(method: PaymentMethod | string): string {
  const normalized = normalizePaymentMethod(method);
  return PAYMENT_CONFIGS[normalized]?.shortLabel || 'Outro';
}

/**
 * Primary payment methods for bar operations
 */
export const PRIMARY_BAR_PAYMENTS: Array<'fisico' | 'emola' | 'mpesa' | 'mkash'> = [
  'fisico',
  'emola',
  'mpesa',
  'mkash',
];
