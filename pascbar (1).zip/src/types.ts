export type ProductCategory =
  | 'Cerveja'
  | 'Refrigerante'
  | 'Cider'
  | 'Destilado'
  | 'Vinho'
  | 'Energético'
  | 'Água'
  | 'Petisco'
  | 'Outros';

export type PaymentMethod =
  | 'fisico'
  | 'emola'
  | 'mpesa'
  | 'mkash'
  | 'cartao'
  | 'fiado'
  | 'outro'
  | 'dinheiro'
  | 'mpesa_emola';

export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  volume?: string; // ex: '330ml', 'Lata', 'Garrafa 500ml'
  costPrice: number; // Preço de custo / compra
  sellPrice: number; // Preço de venda padrão
  currentStock: number; // Quantidade atual existente
  minStockAlert: number; // Limite mínimo para alerta (ex: 5)
  totalSold: number; // Total de saídas acumuladas
  initialStock?: number;
  createdAt: string;
  updatedAt: string;
}

export interface SaleItem {
  productId: string;
  productName: string;
  quantity: number;
  unitCost: number;
  unitPrice: number; // Preço efetivamente confirmado/ditado
  subtotal: number;
  profit: number; // (unitPrice - unitCost) * quantity
}

export interface Sale {
  id: string;
  timestamp: string; // ISO string
  dateStr: string; // YYYY-MM-DD
  timeStr: string; // HH:mm
  items: SaleItem[];
  totalAmount: number;
  totalCost: number;
  totalProfit: number;
  paymentMethod: PaymentMethod;
  customerName?: string;
  customerPhone?: string; // Telefone do cliente (para cobrança por WhatsApp/ligação)
  dueDate?: string; // Data prevista para pagamento do fiado
  notes?: string;
  isReversed?: boolean; // Se foi cancelada/estornada
  isPaid?: boolean; // Para fiados: false = conta pendente/dívida, true = liquidada
  paidAt?: string; // Timestamp de liquidação da dívida
  paidDateStr?: string; // YYYY-MM-DD em que a dívida foi quitada
  settlementMethod?: PaymentMethod; // Como o cliente pagou a dívida (fisico, emola, mpesa, mkash, etc)
}

export interface CashClosure {
  id: string;
  dateStr: string; // YYYY-MM-DD
  closedAt: string; // ISO
  totalRevenue: number;
  totalCost: number;
  totalProfit: number;
  totalSalesCount: number;
  totalDrinksSold: number;
  paymentBreakdown: {
    fisico: number;
    emola: number;
    mpesa: number;
    mkash: number;
    cartao: number;
    fiado: number;
    outro: number;
    dinheiro?: number;
    mpesa_emola?: number;
  };
  physicalCashCounted?: number;
  cashDifference?: number; // physical - esperado
  notes?: string;
  closedBy?: string;
}

export interface Expense {
  id: string;
  dateStr: string;
  description: string;
  category: 'gelo' | 'reposicao' | 'energia' | 'salario' | 'limpeza' | 'outro';
  amount: number;
  timestamp: string;
}

export interface BarSettings {
  barName: string;
  currency: string; // Padrão: "MT" ou "MZN"
  backupCode: string; // Código único para restaurar nuvem (ex: PASC-7821)
  ownerPhone?: string;
  soundEnabled: boolean;
  fastSaleMode: boolean; // Venda direta sem confirmação de preço
  autoCloudSync: boolean;
}

export interface LicenseState {
  isActivated: boolean;
  activatedAt?: string;
  activationKeyUsed?: string;
  installedAt: string; // ISO
  trialDays: number; // 7 dias
}

export interface AppDataBackup {
  version: number;
  exportedAt: string;
  backupCode: string;
  settings: BarSettings;
  license: LicenseState;
  products: Product[];
  sales: Sale[];
  closures: CashClosure[];
  expenses: Expense[];
}
