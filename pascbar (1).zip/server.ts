import express from "express";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

// Enable JSON parsing
app.use(express.json({ limit: "50mb" }));

// Persistent directory for Cloud Backups
const DATA_DIR = path.join(process.cwd(), "data");
const BACKUP_FILE = path.join(DATA_DIR, "cloud_backups.json");

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// In-memory + file-backed cloud store
interface CloudDataStore {
  [backupCode: string]: {
    backupCode: string;
    barName: string;
    lastUpdated: string;
    data: any;
  };
}

let cloudStore: CloudDataStore = {};

// Load existing backups from disk
try {
  if (fs.existsSync(BACKUP_FILE)) {
    const raw = fs.readFileSync(BACKUP_FILE, "utf-8");
    cloudStore = JSON.parse(raw);
    console.log(`[PascBar Cloud] Loaded ${Object.keys(cloudStore).length} backups from disk.`);
  }
} catch (err) {
  console.error("[PascBar Cloud] Error reading backups file:", err);
  cloudStore = {};
}

function saveBackupsToDisk() {
  try {
    fs.writeFileSync(BACKUP_FILE, JSON.stringify(cloudStore, null, 2), "utf-8");
  } catch (err) {
    console.error("[PascBar Cloud] Failed to save backups to disk:", err);
  }
}

// ==================== API ROUTES ====================

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", app: "PascBar", timestamp: new Date().toISOString() });
});

// Real-time Cloud Sync / Upload
app.post("/api/cloud/sync/:backupCode", (req, res) => {
  try {
    const { backupCode } = req.params;
    const { data, barName, clientTimestamp } = req.body;

    if (!backupCode || !data) {
      return res.status(400).json({ error: "Código de backup e dados são obrigatórios." });
    }

    const cleanCode = backupCode.trim().toUpperCase();

    // Store in cloud
    cloudStore[cleanCode] = {
      backupCode: cleanCode,
      barName: barName || "PascBar",
      lastUpdated: new Date().toISOString(),
      data,
    };

    saveBackupsToDisk();

    console.log(`[PascBar Cloud] Synced backup for ${cleanCode} at ${new Date().toLocaleTimeString()}`);

    return res.json({
      success: true,
      backupCode: cleanCode,
      lastUpdated: cloudStore[cleanCode].lastUpdated,
      message: "Dados sincronizados com a nuvem com sucesso!",
    });
  } catch (error: any) {
    console.error("[PascBar Cloud] Sync error:", error);
    return res.status(500).json({ error: "Erro ao sincronizar com a nuvem." });
  }
});

// Cloud Restore / Fetch data (e.g. lost phone recovery)
app.get("/api/cloud/restore/:backupCode", (req, res) => {
  try {
    const { backupCode } = req.params;
    if (!backupCode) {
      return res.status(400).json({ error: "Código de backup é obrigatório." });
    }

    const cleanCode = backupCode.trim().toUpperCase();
    const record = cloudStore[cleanCode];

    if (!record) {
      return res.status(404).json({
        error: "Nenhum backup encontrado para este código.",
        message: "Verifique o código ou crie um novo registo.",
      });
    }

    return res.json({
      success: true,
      backupCode: cleanCode,
      barName: record.barName,
      lastUpdated: record.lastUpdated,
      data: record.data,
    });
  } catch (error: any) {
    console.error("[PascBar Cloud] Restore error:", error);
    return res.status(500).json({ error: "Erro ao restaurar dados da nuvem." });
  }
});

// Cloud Status check
app.get("/api/cloud/status/:backupCode", (req, res) => {
  try {
    const { backupCode } = req.params;
    const cleanCode = (backupCode || "").trim().toUpperCase();
    const record = cloudStore[cleanCode];

    if (!record) {
      return res.json({ exists: false, message: "Código ainda não sincronizado." });
    }

    return res.json({
      exists: true,
      backupCode: cleanCode,
      barName: record.barName,
      lastUpdated: record.lastUpdated,
    });
  } catch (error: any) {
    return res.status(500).json({ error: "Erro ao verificar estado." });
  }
});

// ==================== VITE MIDDLEWARE & SERVER START ====================

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[PascBar] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
